# The course's texture library in Blender (docs/gt2/TEXTURE-LIBRARY.md): the "GT2 texture library" panel.
#
# * The library lives inside the course's export folder (gt2-edit/<course>/textures/library.json), made by
#   `gt2-tools texture library init` from the player's own install. This module only runs gt2-tools and shows
#   the pictures: a grid of the entries (the classic 16-color copies), the selected one's classic copy beside its
#   full-size source, Add picture (a file browser, or drag a PNG/JPG into the 3D view while "Drop pictures here"
#   is on), Pull from another course, Remove, Remove unused, the VRAM fill bar (`texture library report --json`
#   against the faces as they are now), "Use on selected faces" (material lib:ID, UVs from the entry's view) and
#   "Build with library" (`gt2-tools edit ... --library DIR`).
# * Pictures are LINKED from their files, never packed into the .blend (the game's pictures are game pixels;
#   course_edit's save handler unpacks any image flagged gt2_page, and these images carry that flag).
#
# course_edit.py (TRACKTOOL-A's) keeps its own Edit / Build buttons; this panel adds to them.

import json
import os
import shutil
import tempfile

import bpy
import bpy.utils.previews

from . import course_edit

LIB_PROP = "gt2_texlib"        # the library's textures folder on the edit collection
_pv = {"coll": None, "key": None, "items": []}
_lib_cache = {"path": None, "mtime": None, "data": None}
_fill = {"key": None, "data": None}


def _pkg():
    from . import check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod
    return check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod


def lib_dir(col):
    """The textures folder of the library for an edit collection (absolute), or None."""
    if col is None:
        return None
    if LIB_PROP in col:
        return bpy.path.abspath(col[LIB_PROP])
    base = bpy.path.abspath("//") if bpy.data.filepath else (bpy.app.tempdir or tempfile.gettempdir())
    return os.path.join(base, "gt2-edit", col[course_edit.COLLECTION_PROP], "textures")


def load_library(tex):
    """library.json as a dict (cached by modification time), or None."""
    if not tex:
        return None
    p = os.path.join(tex, "library.json")
    if not os.path.isfile(p):
        return None
    m = os.path.getmtime(p)
    if _lib_cache["path"] != p or _lib_cache["mtime"] != m:
        with open(p, encoding="utf-8") as f:
            _lib_cache.update(path=p, mtime=m, data=json.load(f))
    return _lib_cache["data"]


def entry(lib, eid):
    for e in (lib or {}).get("entries", []):
        if e["id"] == eid:
            return e
    return None


def used_ids(col):
    """Faces per lib:ID in the edit collection's meshes."""
    n = {}
    for ob in course_edit.edit_objects(col):
        me = ob.data
        mats = [m.name if m is not None else "" for m in me.materials]
        for p in me.polygons:
            if p.material_index < len(mats):
                name = mats[p.material_index]
                base = name.split(".")[0] if name.count(".") == 1 and name.rsplit(".", 1)[1].isdigit() else name
                if base.startswith("lib:"):
                    n[base[4:]] = n.get(base[4:], 0) + 1
    return n


def _previews():
    if _pv["coll"] is None:
        _pv["coll"] = bpy.utils.previews.new()
    return _pv["coll"]


def grid_items(self, context):
    """Enum items for the picture grid: one per entry (the course's own ones only with "Show the course's own")."""
    col = course_edit.edit_collection(context)
    tex = lib_dir(col)
    lib = load_library(tex)
    if lib is None:
        _pv["items"] = [("NONE", "No library", "Make the library first", 0, 0)]
        return _pv["items"]
    wm = context.window_manager
    own = getattr(wm, "gt2_texlib_show_own", False)
    key = (tex, _lib_cache["mtime"], own)
    if _pv["key"] == key:
        return _pv["items"]
    pc = _previews()
    items = []
    for i, e in enumerate(lib["entries"]):
        if e.get("base") and not own:
            continue
        p = os.path.join(tex, e["classic"])
        k = f"{tex}|{e['id']}|{e.get('classic_from', '')}"
        icon = pc[k].icon_id if k in pc else (pc.load(k, p, 'IMAGE').icon_id if os.path.isfile(p) else 0)
        items.append((e["id"], e["id"], f"{e['origin']} {e['size'][0]}x{e['size'][1]} {','.join(e.get('tags', []))}", icon, i))
    if not items:
        items = [("NONE", "No pictures yet", "Add a picture or pull one from another course", 0, 0)]
    _pv.update(key=key, items=items)
    return items


def _icon(tex, rel, tag):
    pc = _previews()
    p = os.path.join(tex, rel)
    k = f"{tag}|{p}|{os.path.getmtime(p) if os.path.isfile(p) else 0}"
    if k in pc:
        return pc[k].icon_id
    return pc.load(k, p, 'IMAGE').icon_id if os.path.isfile(p) else 0


def lib_material(tex, e):
    """Material lib:ID showing the classic copy (linked, closest texel)."""
    name = "lib:" + e["id"]
    m = bpy.data.materials.get(name)
    if m is None:
        m = bpy.data.materials.new(name)
    path = os.path.join(tex, e["classic"])
    img = None
    for i in bpy.data.images:
        if os.path.normcase(os.path.abspath(bpy.path.abspath(i.filepath))) == os.path.normcase(os.path.abspath(path)):
            img = i
            break
    if img is None and os.path.isfile(path):
        img = bpy.data.images.load(path, check_existing=True)
        img.name = name
        course_edit._set_image_linked(img)
    if img is not None:
        course_edit._textured_material(m, img, {"entry": -1, "uv": [[0, 0]], "page": e["classic"]})
        m["gt2_lib_id"] = e["id"]
    else:
        m.diffuse_color = course_edit.meshonly.name_colour(name)
    return m


def view_uvs(e, corners):
    w, h = e["size"]
    uv = e["uv"]
    return [((uv[c % len(uv)][0] + 0.5) / w, 1.0 - (uv[c % len(uv)][1] + 0.5) / h) for c in corners]


def assign(ob, tex, e, faces=None):
    """Faces of `ob` (indices; None = selected) to material lib:ID with the entry's view UVs; returns the count."""
    mat = lib_material(tex, e)
    me = ob.data
    slot = next((i for i, m in enumerate(me.materials) if m is not None and m.name == mat.name), None)
    if slot is None:
        me.materials.append(mat)
        slot = len(me.materials) - 1
    if ob.mode == 'EDIT':
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        cl = bm.loops.layers.int.get("_GT2_CORNER")
        fl = bm.faces.layers.int.get("_GT2_FACE")
        uvl = bm.loops.layers.uv.get(course_edit.UV_NAME) or bm.loops.layers.uv.active
        bm.faces.ensure_lookup_table()
        sel = [bm.faces[i] for i in faces] if faces is not None else [f for f in bm.faces if f.select]
        for f in sel:
            f.material_index = slot
            if uvl is not None:
                gt2 = fl is not None and f[fl] > 0
                cs = [l[cl] if (gt2 and cl is not None) else k for k, l in enumerate(f.loops)]
                for l, uv in zip(f.loops, view_uvs(e, cs)):
                    l[uvl].uv = uv
        bmesh.update_edit_mesh(me)
        return len(sel)
    sel = faces if faces is not None else [p.index for p in me.polygons if p.select]
    ca = me.attributes.get("_GT2_CORNER")
    fa = me.attributes.get("_GT2_FACE")
    uvl = me.uv_layers.get(course_edit.UV_NAME) or me.uv_layers.active
    for i in sel:
        p = me.polygons[i]
        p.material_index = slot
        if uvl is not None:
            gt2 = fa is not None and fa.data[i].value > 0
            cs = [ca.data[li].value if (gt2 and ca is not None) else k for k, li in enumerate(p.loop_indices)]
            for li, uv in zip(p.loop_indices, view_uvs(e, cs)):
                uvl.data[li].uv = uv
    me.update()
    return len(sel)


def _need(op, context, lib_needed=True):
    """(collection, textures folder, port) or None after reporting the problem."""
    check_port, *_ = _pkg()
    problems = check_port()
    if problems:
        op.report({'ERROR'}, problems[0])
        return None
    col = course_edit.edit_collection(context)
    if col is None:
        op.report({'ERROR'}, "No GT2 course: use Edit GT2 course first")
        return None
    tex = lib_dir(col)
    if lib_needed and load_library(tex) is None:
        op.report({'ERROR'}, "No texture library yet: press Make library")
        return None
    return col, tex, _pkg()[2]()


def _refresh():
    _pv["key"] = None
    _fill["key"] = None


class GT2TRACK_OT_texlib_init(bpy.types.Operator):
    """Make the course's texture library from your install (gt2-tools texture library init): every texture of the course, in the course's edit folder"""
    bl_idname = "gt2track.texlib_init"
    bl_label = "Make library"

    def execute(self, context):
        got = _need(self, context, lib_needed=False)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        _, data_path, _, gt2_tools, last_problem, _, _ = _pkg()
        if load_library(tex) is not None:
            self.report({'INFO'}, "The library is there already")
            return {'FINISHED'}
        code, log = gt2_tools("texture", "library", "init", col[course_edit.COLLECTION_PROP], "--out", os.path.dirname(tex),
                              "--data", data_path(port))
        if code != 0:
            self.report({'ERROR'}, f"gt2-tools: {last_problem(log)}")
            return {'CANCELLED'}
        col[LIB_PROP] = bpy.path.relpath(tex) if bpy.data.filepath else tex
        _refresh()
        self.report({'INFO'}, log.strip().splitlines()[0] if log.strip() else "library made")
        return {'FINISHED'}


class GT2TRACK_OT_texlib_add(bpy.types.Operator):
    """Add a picture (PNG or JPG, any size) to the course's texture library: a classic 16-color copy is made at the size of the entry it is like, or 64 texels on the longest side"""
    bl_idname = "gt2track.texlib_add"
    bl_label = "Add picture"

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(default="*.png;*.jpg;*.jpeg", options={'HIDDEN'})
    tags: bpy.props.StringProperty(name="Tags", default="", description="Comma separated: road, kerb, wall, sign, ...")
    like: bpy.props.StringProperty(name="Like", default="", description="A library ID: its size, tags and UV layout")
    size: bpy.props.StringProperty(name="Size", default="", description="WxH texels (width a multiple of 4)")
    dither: bpy.props.BoolProperty(name="Dither", default=False)

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        _, _, _, gt2_tools, last_problem, _, _ = _pkg()
        paths = [os.path.join(self.directory, f.name) for f in self.files if f.name] if self.files and self.directory else [self.filepath]
        added = []
        for p in paths:
            args = ["texture", "library", "add", bpy.path.abspath(p), "--lib", tex]
            for k, v in (("--tags", self.tags), ("--like", self.like), ("--size", self.size)):
                if v.strip():
                    args += [k, v.strip()]
            if self.dither:
                args.append("--dither")
            code, log = gt2_tools(*args)
            if code != 0:
                self.report({'ERROR'}, f"{os.path.basename(p)}: {last_problem(log)}")
                return {'CANCELLED'}
            added.append(log.split(":", 1)[0].strip())
        _refresh()
        if added:
            context.window_manager.gt2_texlib_pick = added[-1]
        self.report({'INFO'}, f"added {', '.join(added)}")
        return {'FINISHED'}


class GT2TRACK_FH_texlib_drop(bpy.types.FileHandler):
    """Drop PNG/JPG files into the 3D view: they go into the course's texture library (while Drop pictures here is on)"""
    bl_idname = "GT2TRACK_FH_texlib_drop"
    bl_label = "GT2 texture library"
    bl_import_operator = "gt2track.texlib_add"
    bl_file_extensions = ".png;.jpg;.jpeg"

    @classmethod
    def poll_drop(cls, context):
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and getattr(context.window_manager, "gt2_texlib_drop", False))


class GT2TRACK_OT_texlib_pull(bpy.types.Operator):
    """Copy a texture of another course of your install into this library (its texels as they are; a game picture, never shared)"""
    bl_idname = "gt2track.texlib_pull"
    bl_label = "Pull from course"

    course: bpy.props.StringProperty(name="Course", default="roma")
    tex_id: bpy.props.StringProperty(name="Texture", default="t000", description="tNNN (gt2-tools course texture list)")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        _, data_path, _, gt2_tools, last_problem, _, _ = _pkg()
        code, log = gt2_tools("texture", "library", "pull", self.course.strip(), self.tex_id.strip(), "--lib", tex,
                              "--data", data_path(port))
        if code != 0:
            self.report({'ERROR'}, f"gt2-tools: {last_problem(log)}")
            return {'CANCELLED'}
        _refresh()
        eid = log.split(":", 1)[0].strip()
        context.window_manager.gt2_texlib_pick = eid
        self.report({'INFO'}, f"pulled {eid}")
        return {'FINISHED'}


def _remove(tex, eid, gt2_tools):
    return gt2_tools("texture", "library", "remove", eid, "--lib", tex)


class GT2TRACK_OT_texlib_remove(bpy.types.Operator):
    """Remove the selected picture from the library (faces that use it must get another material first)"""
    bl_idname = "gt2track.texlib_remove"
    bl_label = "Remove"

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        eid = context.window_manager.gt2_texlib_pick
        e = entry(load_library(tex), eid)
        if e is None:
            self.report({'ERROR'}, "Pick a picture first")
            return {'CANCELLED'}
        if e.get("base"):
            self.report({'ERROR'}, f"{eid} is one of the course's own textures (it stays; unused ones are dropped when packing)")
            return {'CANCELLED'}
        n = used_ids(col).get(eid, 0)
        if n:
            self.report({'ERROR'}, f"{n} faces use lib:{eid}: give them another material first")
            return {'CANCELLED'}
        code, log = _remove(tex, eid, _pkg()[3])
        _refresh()
        self.report({'INFO'} if code == 0 else {'ERROR'}, log.strip().splitlines()[-1] if log.strip() else eid)
        return {'FINISHED'} if code == 0 else {'CANCELLED'}


class GT2TRACK_OT_texlib_remove_unused(bpy.types.Operator):
    """Remove every added or pulled picture no face uses"""
    bl_idname = "gt2track.texlib_remove_unused"
    bl_label = "Remove unused"

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        used = used_ids(col)
        gone = []
        for e in list(load_library(tex)["entries"]):
            if not e.get("base") and used.get(e["id"], 0) == 0:
                code, _ = _remove(tex, e["id"], _pkg()[3])
                if code == 0:
                    gone.append(e["id"])
        _refresh()
        self.report({'INFO'}, f"removed {len(gone)} unused pictures" + (f": {', '.join(gone)}" if gone else ""))
        return {'FINISHED'}


class GT2TRACK_OT_texlib_use(bpy.types.Operator):
    """Give the selected faces the picked library picture (material lib:ID, UVs from its view)"""
    bl_idname = "gt2track.texlib_use"
    bl_label = "Use on selected faces"

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        e = entry(load_library(tex), context.window_manager.gt2_texlib_pick)
        if e is None:
            self.report({'ERROR'}, "Pick a picture first")
            return {'CANCELLED'}
        obs = [o for o in course_edit.edit_objects(col) if o in context.selected_objects or o == context.object] or course_edit.edit_objects(col)[:1]
        n = sum(assign(o, tex, e) for o in obs)
        _fill["key"] = None
        self.report({'INFO'}, f"{n} faces now use lib:{e['id']}")
        return {'FINISHED'}


def _export_current(col):
    d = tempfile.mkdtemp(prefix="gt2texlib")
    return course_edit.export_edit(col, os.path.join(d, "current.glb")), d


class GT2TRACK_OT_texlib_fit(bpy.types.Operator):
    """Check the VRAM fill: the pictures the faces use now against the course's VRAM (gt2-tools texture library report)"""
    bl_idname = "gt2track.texlib_fit"
    bl_label = "Check fit"

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        _, data_path, _, gt2_tools, last_problem, _, _ = _pkg()
        glb, d = _export_current(col)
        try:
            code, log = gt2_tools("texture", "library", "report", "--lib", tex, "--data", data_path(port), "--uses", glb, "--json")
        finally:
            shutil.rmtree(d, ignore_errors=True)
        try:
            js = json.loads(log[log.index("{"):])
        except ValueError:
            self.report({'ERROR'}, f"gt2-tools: {last_problem(log)}")
            return {'CANCELLED'}
        _fill.update(key=True, data=js)
        msg = f"VRAM fill {100 * js['fill']:.0f}%" + ("" if js["ok"] else f": does not fit (over by {js['over_texels']} texels)")
        self.report({'INFO'} if js["ok"] else {'WARNING'}, msg)
        return {'FINISHED'}


class GT2TRACK_OT_texlib_build(bpy.types.Operator):
    """Build the edited course with its texture library (gt2-tools edit --library) and install it as a mod"""
    bl_idname = "gt2track.texlib_build"
    bl_label = "Build with library"

    target: bpy.props.EnumProperty(name="Target", items=[("port", "Port", ""), ("ps1", "PS1 limits", "")], default="port")

    def execute(self, context):
        got = _need(self, context)
        if got is None:
            return {'CANCELLED'}
        col, tex, port = got
        _, data_path, _, gt2_tools, last_problem, mods_path, install_mod = _pkg()
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the build files are written next to it")
            return {'CANCELLED'}
        course = col[course_edit.COLLECTION_PROP]
        cd = bpy.path.abspath("//")
        glb = course_edit.export_edit(col, os.path.join(cd, f"{course}.edited.glb"))
        out = os.path.join(cd, "out", f"{course}-edit")
        modname = f"Edit_{course}"
        args = ["edit", course, glb, "--out", out, "--data", data_path(port), "--mod", modname, "--library", tex,
                "--target", self.target]
        code, log = gt2_tools(*args)
        with open(os.path.join(cd, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: build-log.txt)")
            return {'CANCELLED'}
        src = os.path.join(out, "mods", modname)
        if os.path.isdir(src) and os.listdir(src):
            install_mod(src, mods_path(port), modname)
        self.report({'INFO'}, f"Built {course} with its texture library (mod {modname})")
        return {'FINISHED'}


class GT2TRACK_PT_texture_library(bpy.types.Panel):
    bl_label = "GT2 texture library"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        wm = context.window_manager
        col = course_edit.edit_collection(context)
        if col is None:
            lay.label(text="Edit a GT2 course first.")
            return
        tex = lib_dir(col)
        lib = load_library(tex)
        if lib is None:
            lay.operator("gt2track.texlib_init", icon='TEXTURE')
            lay.label(text="Your install's textures, beside the .blend.")
            return
        lay.template_icon_view(wm, "gt2_texlib_pick", show_labels=True, scale=5.0, scale_popup=4.0)
        lay.prop(wm, "gt2_texlib_show_own")
        e = entry(lib, wm.gt2_texlib_pick)
        if e is not None:
            box = lay.box()
            row = box.row()
            c1 = row.column()
            c1.label(text="Classic")
            c1.template_icon(icon_value=_icon(tex, e["classic"], "classic"), scale=4.0)
            c2 = row.column()
            c2.label(text="Full size")
            c2.template_icon(icon_value=_icon(tex, e["source"], "source"), scale=4.0)
            box.label(text=f"{e['id']}: {e['size'][0]}x{e['size'][1]} texels, {e['origin']}")
            if e.get("tags"):
                box.label(text="Tags: " + ", ".join(e["tags"]))
            if not e.get("share", False):
                box.label(text="A game picture: never shared", icon='INFO')
            box.operator("gt2track.texlib_use", icon='TEXTURE')
        row = lay.row(align=True)
        row.operator("gt2track.texlib_add", icon='ADD')
        row.operator("gt2track.texlib_pull", icon='IMPORT')
        row = lay.row(align=True)
        row.operator("gt2track.texlib_remove", icon='REMOVE')
        row.operator("gt2track.texlib_remove_unused", icon='TRASH')
        lay.prop(wm, "gt2_texlib_drop")
        box = lay.box()
        js = _fill["data"] if _fill["key"] else None
        if js is not None:
            text = f"VRAM {100 * js['fill']:.0f}%" + ("" if js["ok"] else f", over by {js['over_texels']} texels")
            try:
                box.progress(factor=min(1.0, js["fill"]), type='BAR', text=text)
            except (AttributeError, TypeError):
                box.label(text=text)
            if not js["ok"]:
                box.alert = True
                box.label(text=f"Largest free piece: {js['largest_free'][0]}x{js['largest_free'][1]} texels", icon='ERROR')
        box.operator("gt2track.texlib_fit", icon='VIEWZOOM')
        if col.get("gt2_newtrack_mesh"):
            lay.label(text="Build from the GT2 new track panel", icon='INFO')
            return
        row = lay.row(align=True)
        row.operator("gt2track.texlib_build", text="Build (port)", icon='AUTO').target = "port"
        row.operator("gt2track.texlib_build", text="Build (PS1)", icon='AUTO').target = "ps1"


classes = (GT2TRACK_OT_texlib_init, GT2TRACK_OT_texlib_add, GT2TRACK_FH_texlib_drop, GT2TRACK_OT_texlib_pull,
           GT2TRACK_OT_texlib_remove, GT2TRACK_OT_texlib_remove_unused, GT2TRACK_OT_texlib_use,
           GT2TRACK_OT_texlib_fit, GT2TRACK_OT_texlib_build, GT2TRACK_PT_texture_library)


def register():
    bpy.types.WindowManager.gt2_texlib_pick = bpy.props.EnumProperty(name="Picture", items=grid_items)
    bpy.types.WindowManager.gt2_texlib_show_own = bpy.props.BoolProperty(
        name="Show the course's own", default=False, description="Also show the course's own textures in the grid")
    bpy.types.WindowManager.gt2_texlib_drop = bpy.props.BoolProperty(
        name="Drop pictures here", default=False,
        description="PNG/JPG files dropped into the 3D view go into the texture library")
    for c in classes:
        if c is GT2TRACK_FH_texlib_drop and not hasattr(bpy.types, "FileHandler"):
            continue
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass
    if _pv["coll"] is not None:
        bpy.utils.previews.remove(_pv["coll"])
        _pv.update(coll=None, key=None, items=[])
    del bpy.types.WindowManager.gt2_texlib_drop
    del bpy.types.WindowManager.gt2_texlib_show_own
    del bpy.types.WindowManager.gt2_texlib_pick
