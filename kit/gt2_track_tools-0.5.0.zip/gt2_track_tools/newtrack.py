# A GT2 course as a NEW track (docs/gt2/NEW-TRACK-FROM-COURSE.md): open a scene folder written by
# `gt2-tools course export COURSE --new-track` as Blender collections, save it back, build it with
# `gt2-tools track build`.
#
# Collections (under "GT2 new track <course>"):
#   mesh      gt2_track (drawn faces), gt2_collision (the faces the game drives on: moving a face between the two
#             objects makes it a collision face or not), gt2_track_low (the mirror, hidden); the face attributes of
#             course_edit.py (this module reads and writes the meshes with course_edit's functions)
#   route     the route: one vertex per section start (chain order, attribute _GT2_SEC), empties start, split.N
#   walls     one edge per wall (its own two vertices: a wall's normal is rot90(b - a), so the edge direction
#             matters; edge attributes _GT2_WSEC section, _GT2_WID index + 1, 0 = new)
#   ai        one closed poly line per AI kind ai.K (vertex attribute _GT2_NODE = node + 1, 0 = new), with a
#             read-only preview of the arcs ai.K.preview
#   grid      empties grid.NN
#   cameras   empties cam.NNN at each record's anchor (moving one moves the record)
#   objects   empties obj.G.I (instances), bb.S.M.I (billboards), glow.S.M.I (glows)
# The course record (display name, sky, flags, sky_from, lighting_from) is on the top collection's custom
# properties gt2_display_name ... Every part's exported JSON is kept on the collection: what Blender does not show
# (section normals, distances, camera bodies) goes back as it came.
#
# Float precision: Blender holds float32 positions; each exported value is kept as a double custom property, and an
# object or vertex that did not move (within 0.5 mm) writes its original value back, so a Blender round trip
# changes nothing.
#
# Texture library (texture_library.py): the mesh collection carries the scene's textures/ folder (gt2_texlib), so
# the GT2 texture library panel works on it; faces given lib:ID pictures are packed by `track build` (step 11).
# Build for: Port / A-Spec is the course edit panel's choice (window manager gt2_build_target); A-Spec runs
# `track build --target aspec` and its check.json with course_edit's check helpers (budget box, Show buttons).
#
# Headless:  blender -b --factory-startup --python-expr "import sys; sys.path.insert(0, ADDON_PARENT);
#            import gt2_track_tools.newtrack as n; n.cli()" -- open SCENE_DIR [OUT.blend] | save BLEND [SCENE_DIR]

import json
import os
import sys

import bpy
import numpy as np

from . import course_edit
from . import texture_library

ORIG_CO = "gt2_orig_co"         # per-vertex exported position (mesh objects)
TOP_PROP = "gt2_newtrack"        # the scene folder on the top collection
NEWTRACK_MESH = "gt2_newtrack_mesh"  # on the mesh collection (the texture library panel leaves building to this panel)
EPS = 0.0005                     # metres: closer than this to the exported value = not moved
GRID_HEADING = "gt2_grid_heading_deg"
RECORD_KEYS = ["display_name", "sky", "flags", "sky_from", "lighting_from"]


def _b(p):
    """Course axes (x, height, z) -> Blender (x, -z, height)."""
    return (p[0], -p[2], p[1])


def _c(v):
    """Blender -> course axes."""
    return [v[0], v[2], -v[1]]


def _read(d, rel):
    p = os.path.join(d, rel)
    if not os.path.isfile(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _write(d, rel, obj):
    p = os.path.join(d, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, sort_keys=True)
        f.write("\n")


def _same(a, b):
    return all(abs(x - y) <= EPS for x, y in zip(a, b))


def _sub(parent, name):
    c = bpy.data.collections.new(name)
    parent.children.link(c)
    return c


def _empty(col, name, loc, kind='PLAIN_AXES', size=1.0):
    ob = bpy.data.objects.new(name, None)
    ob.empty_display_type = kind
    ob.empty_display_size = size
    ob.location = loc
    col.objects.link(ob)
    return ob


def _line_object(col, name, pts, closed, vattrs=None, edges=None, eattrs=None):
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(pts))
    if pts:
        me.vertices.foreach_set("co", np.array(pts, dtype=np.float32).ravel())
    if edges is None:
        n = len(pts)
        edges = [(i, i + 1) for i in range(n - 1)] + ([(n - 1, 0)] if closed and n > 2 else [])
    me.edges.add(len(edges))
    if edges:
        me.edges.foreach_set("vertices", np.array(edges, dtype=np.int32).ravel())
    me.update()
    for k, vals in (vattrs or {}).items():
        a = me.attributes.new(k, 'INT', 'POINT')
        a.data.foreach_set("value", np.array(vals, dtype=np.int32))
    for k, vals in (eattrs or {}).items():
        a = me.attributes.new(k, 'INT', 'EDGE')
        a.data.foreach_set("value", np.array(vals, dtype=np.int32))
    ob = bpy.data.objects.new(name, me)
    col.objects.link(ob)
    return ob


def _attr(me, name, domain_len):
    a = me.attributes.get(name)
    out = np.zeros(domain_len, dtype=np.int32)
    if a is not None and domain_len:
        a.data.foreach_get("value", out)
    return out


def _cycle(me):
    """The vertices of a mesh of edges in walk order: every connected chain (closed or open), each from its
    vertex with the smallest positive id attribute (else its lowest index), toward its neighbor of smaller id."""
    nbr = {i: [] for i in range(len(me.vertices))}
    for e in me.edges:
        a, b = e.vertices
        nbr[a].append(b)
        nbr[b].append(a)
    return nbr


# ---------------------------------------------------------------------------------------------------------------
# Open


def _ai_preview(nodes):
    """Points along a node line (map metres) as the game follows it: straights, and arcs about
    P - r (cos a, sin a)."""
    out = []
    n = len(nodes)
    for k in range(n):
        a, b = nodes[k], nodes[(k + 1) % n]
        p0, p1 = a["at"], b["at"]
        if a["ty"] == 0 or a["radius_m"] == 0:
            out.append(p0)
            continue
        r = a["radius_m"]
        h = (round(a["heading_deg"] * 4096 / 360) & 0xFFF) / 4096 * 2 * np.pi
        c = (p0[0] - np.cos(h) * r, p0[1] - np.sin(h) * r)
        a0 = np.arctan2(p0[1] - c[1], p0[0] - c[0])
        a1 = np.arctan2(p1[1] - c[1], p1[0] - c[0])
        if r > 0:
            while a1 < a0:
                a1 += 2 * np.pi
        else:
            while a1 > a0:
                a1 -= 2 * np.pi
        steps = max(1, int(abs(a1 - a0) * abs(r) / 2))
        for i in range(steps):
            t = a0 + (a1 - a0) * i / steps
            out.append((c[0] + abs(r) * np.cos(t), c[1] + abs(r) * np.sin(t)))
    return out


def open_scene(d, name=None):
    """Builds the collections of the scene folder `d`; returns the top collection."""
    d = os.path.abspath(d)
    man = _read(d, "scene.json")
    if not man or man.get("format") != "gt2-newtrack-scene":
        raise ValueError(f"{d}: not a new-track scene folder (gt2-tools course export COURSE --new-track)")
    course = man["source"]["course"]
    parts = man["parts"]
    top = bpy.data.collections.new(name or f"GT2 new track {course}")
    bpy.context.scene.collection.children.link(top)
    top[TOP_PROP] = d
    top["gt2_course"] = course
    for k in RECORD_KEYS:
        v = man["course"].get(k)
        top["gt2_" + k] = v if v is not None else ""
    # meshes
    mc = _sub(top, "mesh")
    course_edit.import_edit(os.path.join(d, parts["mesh"]), course, collection=mc)
    # the scene's textures folder: the texture library panel reads and writes its library.json there
    mc[texture_library.LIB_PROP] = os.path.join(d, os.path.dirname(parts.get("textures", "textures/manifest.json")) or "textures")
    mc[NEWTRACK_MESH] = True
    for ob in list(mc.objects):
        if ob.get("gt2_mesh") != "high":
            continue
        coll = _attr(ob.data, "_GT2_COLL", len(ob.data.polygons))
        ob.name = "gt2_collision" if len(coll) and coll.all() else "gt2_track"
        ob["gt2_part"] = "collision" if len(coll) and coll.all() else "drawn"
    for ob in mc.objects:
        # each vertex's exported place (not exported back: no underscore): a vertex of one object moved where the
        # other object has a vertex at the same place drags that one along on save (the drawn and collision
        # faces share vertices in the course)
        me = ob.data
        co = np.zeros(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get("co", co)
        a = me.attributes.new(ORIG_CO, 'FLOAT_VECTOR', 'POINT')
        a.data.foreach_set("vector", co)
    # route
    route = _read(d, parts["route"])
    rc = _sub(top, "route")
    secs = route["sections"]
    pts = [_b(s["point"]) for s in secs]
    ob = _line_object(rc, "route", pts, True, vattrs={"_GT2_SEC": [s["id"] + 1 for s in secs]})
    ob["gt2_orig"] = [c for s in secs for c in s["point"]]
    st = _empty(rc, "start", _b(route["start"]), 'SINGLE_ARROW', 6)
    st["gt2_orig"] = route["start"]
    for k, sp in enumerate(route["splits"]):
        e = _empty(rc, f"split.{k}", _b(sp["at"]), 'CUBE', 2)
        e["gt2_orig"] = sp["at"]
        e["distance_m"] = sp["distance_m"]
    top["gt2_route_json"] = json.dumps(route)
    # walls
    walls = _read(d, parts["walls"]) or {"sections": []}
    wc = _sub(top, "walls")
    wp, ws, wid, orig = [], [], [], []
    for sec in walls["sections"]:
        for w in sec["walls"]:
            wp += [_b(w["a"]), _b(w["b"])]
            ws.append(sec["section"])
            wid.append(w["id"][1] + 1 if w.get("id") and w["id"][0] == sec["section"] else 0)
            orig += w["a"] + w["b"]
    edges = [(2 * i, 2 * i + 1) for i in range(len(ws))]
    ob = _line_object(wc, "walls", wp, False, edges=edges, eattrs={"_GT2_WSEC": ws, "_GT2_WID": wid})
    top["gt2_walls_json"] = json.dumps(walls)
    # AI lines (height: the route's nearest point)
    ai = _read(d, parts["ai"]) or {"lines": []}
    ac = _sub(top, "ai")
    rxy = np.array([[p[0], p[1]] for p in pts]) if pts else np.zeros((1, 2))
    rz = np.array([p[2] for p in pts]) if pts else np.zeros(1)

    def hz(x, y):
        return float(rz[np.argmin((rxy[:, 0] - x) ** 2 + (rxy[:, 1] - y) ** 2)]) + 0.5

    for line in ai["lines"]:
        k = line["kind"]
        nodes = line["nodes"]
        npts = [(n["at"][0], n["at"][1], hz(*n["at"])) for n in nodes]
        ob = _line_object(ac, f"ai.{k}", npts, True, vattrs={"_GT2_NODE": [n["id"] + 1 if n.get("id") is not None else 0 for n in nodes]})
        ob["gt2_kind"] = k
        ob["gt2_orig"] = [c for n in nodes for c in n["at"]]
        ob["gt2_nodes_json"] = json.dumps(nodes)
        pv = _ai_preview(nodes)
        pob = _line_object(ac, f"ai.{k}.preview", [(p[0], p[1], hz(*p)) for p in pv], True)
        pob.hide_select = True
        pob["gt2_preview"] = True
    # grid
    grid = _read(d, parts["grid"]) or {"heading_deg": 0, "slots": []}
    gc = _sub(top, "grid")
    top[GRID_HEADING] = grid["heading_deg"]
    for k, s in enumerate(grid["slots"]):
        if s is not None:
            e = _empty(gc, f"grid.{k:02d}", _b(s), 'SINGLE_ARROW', 3)
            e["gt2_orig"] = s
            e["gt2_slot"] = k
    # cameras
    cams = _read(d, parts["cameras"]) or {"lap_mod": 0, "records": []}
    cc = _sub(top, "cameras")
    top["gt2_cameras_json"] = json.dumps(cams)
    for r in cams["records"]:
        if r.get("at") is None:
            continue
        e = _empty(cc, f"cam.{r['id']:03d}", _b(r["at"]), 'CONE' if r["kind"] == 1 else 'SPHERE', 2)
        e["gt2_orig"] = r["at"]
        e["gt2_id"] = r["id"]
        e["start_m"], e["end_m"] = r["start_m"], r["end_m"]
        e["laps"] = r["laps"]
    # objects
    objs = _read(d, parts["objects"]) or {"instances": [], "billboards": [], "glows": []}
    oc = _sub(top, "objects")
    for i in objs["instances"]:
        g, k = i["id"] if i.get("id") else (i.get("group", 32), 0)
        e = _empty(oc, f"obj.{g}.{k}", _b(i["at"]), 'ARROWS', 3)
        e["gt2_orig"] = i["at"]
        e["gt2_id"] = i["id"] if i.get("id") else [-1, -1]
        e["group"], e["object"], e["rot"], e["scale"] = i.get("group", g), i["object"], i["rot"], i["scale"]
    for kind, lst in (("bb", objs["billboards"]), ("glow", objs["glows"])):
        for b in lst:
            s, m_, k = b["id"] if b.get("id") else (b["section"], int(b.get("low", False)), 0)
            e = _empty(oc, f"{kind}.{s}.{m_}.{k}", _b(b["at"]), 'SINGLE_ARROW' if kind == "bb" else 'SPHERE', 2)
            e["gt2_orig"] = b["at"]
            e["gt2_json"] = json.dumps(b)
    return top


# ---------------------------------------------------------------------------------------------------------------
# Save


def _pos(ob):
    return list(ob.matrix_world.translation)


def _keep(ob, cur):
    """The object's position in course axes: its exported value when it did not move."""
    o = list(ob.get("gt2_orig", []))
    c = _c(cur)
    return o if len(o) == 3 and _same(c, o) else c


def _children(top, name):
    for c in top.children:
        if c.name.split(".")[0] == name:
            return c
    return None


def _walk_chain(me, ids):
    """Vertex order of a closed poly line: from the vertex with the smallest positive id, toward the export's
    next node (id + 1, or a new vertex inserted before it), then along the edges."""
    nbr = _cycle(me)
    n = len(me.vertices)
    if n == 0:
        return []
    cand = [i for i in range(n) if ids[i] > 0]
    start = min(cand, key=lambda i: ids[i]) if cand else 0
    first = nbr[start]
    if len(first) > 1:
        nxt = [v for v in first if ids[v] == ids[start] + 1]
        if not nxt:
            top_id = max(int(ids[v]) for v in first)
            nxt = [v for v in first if ids[v] != top_id] or first
        first = nxt
    order, seen, prev, cur = [start], {start}, start, (first[0] if first else None)
    while cur is not None and cur not in seen:
        order.append(cur)
        seen.add(cur)
        nx = [v for v in nbr[cur] if v != prev and v not in seen]
        prev, cur = cur, (nx[0] if nx else None)
    return order


def _join_moves(obs):
    """Vertices that sat at one place on export (in any of `obs`) move together: where some moved and others did
    not, the unmoved ones take the (first) moved position."""
    data = []
    for ob in obs:
        me = ob.data
        a = me.attributes.get(ORIG_CO)
        if a is None:
            continue
        n = len(me.vertices)
        o = np.zeros(n * 3, dtype=np.float32)
        a.data.foreach_get("vector", o)
        c = np.zeros(n * 3, dtype=np.float32)
        me.vertices.foreach_get("co", c)
        data.append((ob, o.reshape(-1, 3), c.reshape(-1, 3)))
    target = {}
    for ob, o, c in data:
        moved = np.any(np.abs(o - c) > 1e-6, axis=1)
        for i in np.nonzero(moved)[0]:
            target.setdefault(o[i].tobytes(), c[i].copy())
    if not target:
        return 0
    n = 0
    for ob, o, c in data:
        moved = np.any(np.abs(o - c) > 1e-6, axis=1)
        changed = False
        for i in np.nonzero(~moved)[0]:
            t = target.get(o[i].tobytes())
            if t is not None:
                c[i] = t
                changed = True
                n += 1
        if changed:
            ob.data.vertices.foreach_set("co", c.ravel())
            ob.data.update()
    return n


def save_scene(top, d=None):
    """Writes the collections back into the scene folder (default: the one they were opened from)."""
    d = os.path.abspath(d or top[TOP_PROP])
    man = _read(top[TOP_PROP], "scene.json")
    parts = man["parts"]
    # course record
    for k in RECORD_KEYS:
        v = top.get("gt2_" + k)
        if k in ("sky", "flags"):
            man["course"][k] = int(v or 0)
        elif k in ("sky_from", "lighting_from"):
            if v:
                man["course"][k] = str(v)
            else:
                man["course"].pop(k, None)
        else:
            man["course"][k] = str(v)
    # meshes: _GT2_COLL from the object a face is in
    mc = _children(top, "mesh")
    _join_moves([o for o in mc.objects if o.get("gt2_part") in ("drawn", "collision")])
    for ob in mc.objects:
        part = ob.get("gt2_part")
        if part in ("drawn", "collision"):
            me = ob.data
            a = me.attributes.get("_GT2_COLL") or me.attributes.new("_GT2_COLL", 'INT', 'FACE')
            a.data.foreach_set("value", np.full(len(me.polygons), 1 if part == "collision" else 0, dtype=np.int32))
    course_edit.export_edit(mc, os.path.join(d, parts["mesh"]))
    # route
    route = json.loads(top["gt2_route_json"])
    rc = _children(top, "route")
    rob = rc.objects["route"] if "route" in rc.objects else next(o for o in rc.objects if o.type == 'MESH')
    me = rob.data
    ids = _attr(me, "_GT2_SEC", len(me.vertices))
    orig = list(rob.get("gt2_orig", []))
    by = {s["id"]: s for s in route["sections"]}
    for vi, v in enumerate(me.vertices):
        sid = int(ids[vi]) - 1
        if sid not in by:
            raise ValueError(f"route: vertex {vi} has no section (sections cannot be added in version 1)")
        s = by[sid]
        c = _c(rob.matrix_world @ v.co)
        k = route["sections"].index(s)
        o = orig[3 * k:3 * k + 3]
        s["point"] = o if len(o) == 3 and _same(c, o) else c
    for ob in rc.objects:
        if ob.name == "start":
            route["start"] = _keep(ob, _pos(ob))
    splits = sorted([o for o in rc.objects if o.name.startswith("split.")], key=lambda o: int(o.name.split(".")[1]))
    route["splits"] = [{"at": _keep(o, _pos(o)), "distance_m": float(o["distance_m"])} for o in splits]
    _write(d, parts["route"], route)
    # walls
    wc = _children(top, "walls")
    out = {}
    for ob in wc.objects:
        if ob.type != 'MESH':
            continue
        me = ob.data
        ws = _attr(me, "_GT2_WSEC", len(me.edges))
        wid = _attr(me, "_GT2_WID", len(me.edges))
        okey = {}
        k = 0
        # the exported walls: (section, index) -> their original ends
        walls0 = json.loads(top["gt2_walls_json"])
        for sec in walls0["sections"]:
            for w in sec["walls"]:
                okey[tuple(w["id"])] = (w["a"], w["b"])
        used = set()
        for ei, e in enumerate(me.edges):
            a, b = e.vertices
            pa, pb = _c(ob.matrix_world @ me.vertices[a].co), _c(ob.matrix_world @ me.vertices[b].co)
            s = int(ws[ei])
            key = (s, int(wid[ei]) - 1)
            w = {}
            if wid[ei] > 0 and key in okey and key not in used:
                used.add(key)
                oa, ob_ = okey[key]
                w["id"] = [s, key[1]]
                pa = oa if _same(pa, oa) else pa
                pb = ob_ if _same(pb, ob_) else pb
            w["a"], w["b"] = pa, pb
            out.setdefault(s, []).append(w)
            k += 1
    # keep the source's order within a section (ids first in their order, new walls after)
    secs = []
    for s in sorted(out):
        lst = out[s]
        lst.sort(key=lambda w: (0, w["id"][1]) if "id" in w else (1, 0))
        secs.append({"section": s, "walls": lst})
    _write(d, parts["walls"], {"sections": secs})
    # AI lines
    acol = _children(top, "ai")
    lines = []
    for ob in acol.objects:
        if ob.type != 'MESH' or ob.get("gt2_preview") or "gt2_kind" not in ob:
            continue
        me = ob.data
        ids = _attr(me, "_GT2_NODE", len(me.vertices))
        nodes0 = json.loads(ob["gt2_nodes_json"])
        by = {n["id"]: n for n in nodes0 if n.get("id") is not None}
        orig = list(ob.get("gt2_orig", []))
        order = _walk_chain(me, ids)
        seen = set()
        nodes = []
        for vi in order:
            v = ob.matrix_world @ me.vertices[vi].co
            nid = int(ids[vi]) - 1
            if nid in by and nid not in seen:
                seen.add(nid)
                n = dict(by[nid])
                o = orig[2 * nid:2 * nid + 2]
                p = [v[0], v[1]]
                n["at"] = o if len(o) == 2 and _same(p, o) else p
            else:
                n = {"ty": 0, "at": [v[0], v[1]], "heading_deg": 0.0, "radius_m": 0.0}
            nodes.append(n)
        lines.append({"kind": int(ob["gt2_kind"]), "nodes": nodes})
    lines.sort(key=lambda l: l["kind"])
    _write(d, parts["ai"], {"lines": lines})
    # grid
    gcol = _children(top, "grid")
    grid0 = _read(top[TOP_PROP], parts["grid"]) or {"slots": [None] * 16}
    slots = [None] * max(16, len(grid0["slots"]))
    for ob in gcol.objects:
        k = int(ob.get("gt2_slot", ob.name.split(".")[1]))
        slots[k] = _keep(ob, _pos(ob))
    _write(d, parts["grid"], {"heading_deg": float(top.get(GRID_HEADING, 0.0)), "slots": slots[:16]})
    # cameras
    cams = json.loads(top["gt2_cameras_json"])
    ccol = _children(top, "cameras")
    present = {}
    for ob in ccol.objects:
        present[int(ob["gt2_id"])] = ob
    recs = []
    for r in cams["records"]:
        ob = present.get(r["id"])
        if r.get("at") is not None and ob is None:
            continue  # deleted in Blender
        if ob is not None:
            r["at"] = _keep(ob, _pos(ob))
            r["start_m"], r["end_m"] = float(ob["start_m"]), float(ob["end_m"])
            r["laps"] = [int(x) for x in ob["laps"]]
        recs.append(r)
    cams["records"] = recs
    _write(d, parts["cameras"], cams)
    # objects
    ocol = _children(top, "objects")
    inst, bbs, gls = [], [], []
    for ob in sorted(ocol.objects, key=lambda o: o.name):
        if ob.name.startswith("obj."):
            gid = [int(x) for x in ob["gt2_id"]]
            i = {"object": int(ob["object"]), "at": _keep(ob, _pos(ob)), "rot": [int(x) for x in ob["rot"]],
                 "scale": [int(x) for x in ob["scale"]], "group": int(ob["group"])}
            # a copy made in Blender (Shift+D) carries the original's id: the first keeps it
            key = tuple(gid)
            if gid[0] >= 0 and key not in {tuple(x.get("id", [])) for x in inst}:
                i["id"] = gid
            inst.append(i)
        elif ob.name.startswith("bb.") or ob.name.startswith("glow."):
            b = json.loads(ob["gt2_json"])
            b["at"] = _keep(ob, _pos(ob))
            (bbs if ob.name.startswith("bb.") else gls).append(b)
    # the source's order: ids in their order, new ones after
    inst.sort(key=lambda i: (0, i["id"][0], i["id"][1]) if "id" in i else (1, i["group"], 0))
    for lst in (bbs, gls):
        seen = set()
        for b in lst:
            if b.get("id") is not None:
                t = tuple(b["id"])
                if t in seen:
                    del b["id"]
                seen.add(t)
        lst.sort(key=lambda b: (0, b["id"]) if b.get("id") is not None else (1, [b["section"]]))
    _write(d, parts["objects"], {"instances": inst, "billboards": bbs, "glows": gls})
    _write(d, "scene.json", man)
    return d


def scene_collection(context=None):
    for c in bpy.data.collections:
        if TOP_PROP in c:
            return c
    return None


# ---------------------------------------------------------------------------------------------------------------
# Headless entry


def cli():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if not argv:
        print("newtrack: open SCENE_DIR [OUT.blend] | save BLEND [SCENE_DIR]  (save: run with the .blend opened)")
        return
    cmd = argv[0]
    if cmd == "open":
        top = open_scene(argv[1])
        if len(argv) > 2:
            bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(argv[2]))
        print(f"newtrack: opened {argv[1]} as {top.name}")
    elif cmd == "save":
        top = scene_collection()
        d = save_scene(top, argv[1] if len(argv) > 1 else None)
        print(f"newtrack: saved {d}")


# ---------------------------------------------------------------------------------------------------------------
# UI


def _pkg():
    from . import (check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir)
    return check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir


class GT2TRACK_OT_newtrack_export(bpy.types.Operator):
    """Export a GT2 course from your own data as a new track (every part editable) and open it"""
    bl_idname = "gt2track.newtrack_export"
    bl_label = "New track from course"

    course: bpy.props.StringProperty(name="Course", default="laguna")

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        work = work_dir("gt2-newtrack", need_saved=True)
        if work is None:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the scene folder is written next to it")
            return {'CANCELLED'}
        course = self.course.strip()
        out = os.path.join(work, course)
        code, log = gt2_tools("course", "export", course, "--new-track", "--textures", "--data", data_path(port_dir()), "--out", out)
        if code != 0:
            self.report({'ERROR'}, f"gt2-tools could not export {course}: {last_problem(log)}")
            return {'CANCELLED'}
        top = open_scene(out)
        self.report({'INFO'}, f"{course} opened as {top.name} (scene folder gt2-newtrack/{course}; never share it)")
        return {'FINISHED'}


class GT2TRACK_OT_newtrack_save(bpy.types.Operator):
    """Write the new track's parts back into its scene folder"""
    bl_idname = "gt2track.newtrack_save"
    bl_label = "Save scene"

    def execute(self, context):
        top = scene_collection(context)
        if top is None:
            self.report({'ERROR'}, "No new track open")
            return {'CANCELLED'}
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        d = save_scene(top)
        self.report({'INFO'}, f"Saved {d}")
        return {'FINISHED'}


class GT2TRACK_OT_newtrack_build(bpy.types.Operator):
    """Save the scene and build it: for the port (a new course in your mods) or for a PS1 disc (replaces a slot)"""
    bl_idname = "gt2track.newtrack_build"
    bl_label = "Build new track"

    target: bpy.props.EnumProperty(name="For", items=[("port", "The port", "A new course in your mods"),
                                                       ("ps1", "PS1 disc", "Replaces a course slot, within the console's limits"),
                                                       ("aspec", "A-Spec", "Replaces a course slot: the stock game's checks, then a verified A-Spec v1.2.1 xdelta"),
                                                       ("check", "Check for A-Spec", "The A-Spec checks without the image")])
    name: bpy.props.StringProperty(name="Course id", default="", description="Port: the new course's id (zz_...); PS1: the slot it replaces (empty: the source course)")

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir = _pkg()
        top = scene_collection(context)
        if top is None:
            self.report({'ERROR'}, "No new track open")
            return {'CANCELLED'}
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        d = save_scene(top)
        if self.target in ("aspec", "check"):
            return _aspec_build(self, top, d)
        port = port_dir()
        out = os.path.join(os.path.dirname(d), "out", os.path.basename(d) + "-" + self.target)
        modname = "NewTrack_" + top["gt2_course"]
        args = ["track", "build", d, "--target", self.target, "--data", data_path(port), "--out", out, "--mod", modname]
        if self.name.strip():
            args += ["--add" if self.target == "port" else "--slot", self.name.strip()]
        code, log = gt2_tools(*args)
        with open(os.path.join(os.path.dirname(d), "newtrack-build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: newtrack-build-log.txt)")
            return {'CANCELLED'}
        src = os.path.join(out, "mods", modname)
        if self.target == "port" and os.path.isdir(src):
            install_mod(src, mods_path(port), modname)
            self.report({'INFO'}, f"Built and installed {modname}")
        else:
            self.report({'INFO'}, f"Built {out} (PS1 files: make the disc patch from them)")
        return {'FINISHED'}


def mesh_collection(top):
    return next((c for c in top.children if c.get(NEWTRACK_MESH)), None) if top is not None else None


def _aspec_build(op, top, d):
    """`track build --target aspec` (check: --check-only) with --json; the result on the mesh collection, a finding
    selects its faces (course_edit's helpers, the same as the course edit panel's A-Spec build)."""
    _, _, _, gt2_tools, last_problem, _, _, _ = _pkg()
    mc = mesh_collection(top)
    check_only = op.target == "check"
    out = os.path.join(os.path.dirname(d), "out", os.path.basename(d) + "-aspec")
    js_path = os.path.join(out, "check.json")
    if os.path.exists(js_path):
        os.remove(js_path)
    args = ["track", "build", d, "--target", "aspec", "--out", out, "--mod", "NewTrack_" + top["gt2_course"],
            "--json", js_path] + course_edit.aspec_cache_args()
    if op.name.strip():
        args += ["--slot", op.name.strip()]
    if check_only:
        args.append("--check-only")
    code, log = gt2_tools(*args, timeout=1800)
    with open(os.path.join(os.path.dirname(d), "newtrack-build-log.txt"), "w", encoding="utf-8") as f:
        f.write(log)
    js = course_edit.store_check(mc, js_path) if mc is not None else None
    if js is None:
        op.report({'ERROR'}, f"gt2-tools: {last_problem(log)}  (all of it: newtrack-build-log.txt)")
        return {'CANCELLED'}
    if not js.get("ok"):
        fs = course_edit.findings(js)
        errs = js.get("errors", [])
        first = fs[0] if fs else (errs[0] if errs else None)
        n = course_edit.select_finding(mc, first) if fs else 0
        where = f" ({n} faces selected)" if n else ""
        msg = first["message"] if first else last_problem(log)
        op.report({'ERROR'}, f"Not for A-Spec: {msg}{where}  (all of it: newtrack-build-log.txt)")
        return {'CANCELLED'}
    if check_only:
        op.report({'INFO'}, f"{top['gt2_course']}: within A-Spec's limits (nothing built)")
        return {'FINISHED'}
    ad = os.path.join(out, "aspec")
    xd = [f for f in os.listdir(ad) if f.endswith(".xdelta")] if code == 0 and os.path.isdir(ad) else []
    if code != 0 or not xd:
        op.report({'ERROR'}, f"The A-Spec build failed: {last_problem(log)}  (all of it: newtrack-build-log.txt)")
        return {'CANCELLED'}
    mc["gt2_aspec_patch"] = os.path.join(ad, xd[0])
    op.report({'INFO'}, f"A-Spec patch: {os.path.join(ad, xd[0])} (verified; README.txt says how to apply it)")
    return {'FINISHED'}


class GT2TRACK_PT_newtrack(bpy.types.Panel):
    bl_label = "GT2 new track"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        top = scene_collection(context)
        lay.operator(GT2TRACK_OT_newtrack_export.bl_idname)
        if top is None:
            lay.label(text="Every edited course is a new track.")
            return
        lay.label(text=f"{top.get('gt2_course')} -> {top.get('gt2_display_name')}")
        box = lay.box()
        for k in ("gt2_display_name", "gt2_sky", "gt2_flags", "gt2_sky_from", "gt2_lighting_from", GRID_HEADING):
            box.prop(top, f'["{k}"]', text=k.replace("gt2_", "").replace("_", " "))
        lay.operator(GT2TRACK_OT_newtrack_save.bl_idname)
        wm = context.window_manager
        row = lay.row(align=True)
        row.label(text="Build for:")
        row.prop(wm, "gt2_build_target", expand=True)
        row = lay.row()
        if wm.gt2_build_target == 'ASPEC':
            row.operator(GT2TRACK_OT_newtrack_build.bl_idname, text="Build for A-Spec").target = "aspec"
            row.operator(GT2TRACK_OT_newtrack_build.bl_idname, text="Check for A-Spec", icon='CHECKMARK').target = "check"
        else:
            row.operator(GT2TRACK_OT_newtrack_build.bl_idname, text="Build for the port").target = "port"
            row.operator(GT2TRACK_OT_newtrack_build.bl_idname, text="Build for PS1").target = "ps1"
        course_edit.draw_check(lay, mesh_collection(top))


classes = (GT2TRACK_OT_newtrack_export, GT2TRACK_OT_newtrack_save, GT2TRACK_OT_newtrack_build, GT2TRACK_PT_newtrack)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
