# Builds the GT2 track starter scene and saves it as a .blend.
#
# The add-on runs this in a second, background Blender (bpy.app.binary_path -b --factory-startup --python
# starter.py -- ...) so the user's open file and settings are never touched, and so the scene is built from factory
# settings exactly as the old make_starter.py built GT2_Track_Starter.blend. That file can no longer be shipped
# (it holds GT2's Laguna Seca); every player builds their own from their own disc's data.
#
# usage: blender -b --factory-startup --python starter.py -- LAGUNA_GLTF SAMPLE_CSV GUIDE_TXT OUT.blend
#
# The scene is make_starter.py's, object for object: a 100 m / 1 km grid, Laguna Seca at true size (mesh only:
# no game textures, materials keep their names), size references, the sample road as the closed line "Track" with _width/_bank point attributes, a
# "Start" empty and a "Place_Home" marker. Unlike the old file it carries no gt2_tools.py text block: the GT2 tab
# now comes from the installed add-on, so the .blend runs no script of its own.
import csv
import math
import os
import sys

import bmesh
import bpy

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import meshonly  # noqa: E402  (run as a script in a background Blender)
import mathutils


def build(gltf, csv_path, guide_path, out):
    # Empty scene, metres.
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.unit_settings.system = 'METRIC'
    sc.unit_settings.scale_length = 1.0
    sc.unit_settings.length_unit = 'METERS'

    def collection(name, color):
        c = bpy.data.collections.new(name)
        sc.collection.children.link(c)
        c.color_tag = color
        return c

    ref = collection("REFERENCE (not exported)", 'COLOR_04')
    yours = collection("YOUR TRACK", 'COLOR_01')

    def move_to(o, col):
        for c in list(o.users_collection):
            c.objects.unlink(o)
        col.objects.link(o)

    def text(body, loc, size, col, rot_z=0.0):
        cu = bpy.data.curves.new("Label", 'FONT')
        cu.body = body
        cu.size = size
        o = bpy.data.objects.new("Label: " + body.splitlines()[0][:30], cu)
        o.location = loc
        o.rotation_euler = (0, 0, rot_z)
        col.objects.link(o)
        o.hide_select = True
        return o

    def mat(name, rgba):
        m = bpy.data.materials.new(name)
        m.diffuse_color = rgba
        return m

    # --- Laguna Seca (GT2's own course, true size) ---
    before, imgs, mats = set(bpy.data.objects), set(bpy.data.images), set(bpy.data.materials)
    bpy.ops.import_scene.gltf(filepath=gltf)
    meshonly.strip_assets(imgs, mats)          # mesh only: no game textures in the .blend
    imported = [o for o in bpy.data.objects if o not in before]
    for o in imported:
        move_to(o, ref)
    # Hide the extra layers of the view (low detail, collision, AI lines) but keep them.
    for o in imported:
        n = o.name.lower()
        if any(w in n for w in ("track_low", "collision", "ai line", "ai_line")):
            o.hide_set(True)
            o.hide_render = True
    roots = [o for o in imported if o.parent is None]
    bpy.context.view_layer.update()
    xs, ys = [], []
    for o in imported:
        if o.type == 'MESH' and not o.hide_get():
            for c in o.bound_box:
                w = o.matrix_world @ mathutils.Vector(c)
                xs.append(w.x)
                ys.append(w.y)
    lx0, lx1, ly0, ly1 = min(xs), max(xs), min(ys), max(ys)
    # The starter road (the sample track) spans x -320..650; put Laguna to its west with a 300 m gap.
    dx = -700.0 - lx1
    dy = -(ly0 + ly1) / 2
    for o in roots:
        o.location.x += dx
        o.location.y += dy
    lag_w, lag_h = lx1 - lx0, ly1 - ly0
    text("Laguna Seca Raceway (from GT2)\n3.6 km lap, true size", (lx0 + dx, ly1 + dy + 60, 0), 40, ref)
    lag_empty = bpy.data.objects.new("Laguna Seca (reference)", None)
    ref.objects.link(lag_empty)
    for o in roots:
        o.parent = lag_empty
        o.matrix_parent_inverse = lag_empty.matrix_world.inverted()

    # --- Grid: 100 m lines over 4 km x 3 km, 1 km lines thicker (as separate objects) ---
    def grid(name, step, x0, x1, y0, y1, color):
        me = bpy.data.meshes.new(name)
        bm = bmesh.new()
        x = x0
        while x <= x1 + 0.1:
            a = bm.verts.new((x, y0, -0.5))
            b = bm.verts.new((x, y1, -0.5))
            bm.edges.new((a, b))
            x += step
        y = y0
        while y <= y1 + 0.1:
            a = bm.verts.new((x0, y, -0.5))
            b = bm.verts.new((x1, y, -0.5))
            bm.edges.new((a, b))
            y += step
        bm.to_mesh(me)
        o = bpy.data.objects.new(name, me)
        o.color = color
        ref.objects.link(o)
        o.hide_select = True
        return o

    grid("Grid 100 m", 100, -2500, 1500, -1500, 1500, (0.5, 0.5, 0.5, 1))
    grid("Grid 1 km", 1000, -2500, 1500, -1500, 1500, (1, 1, 1, 1))
    for x in range(-2000, 1501, 1000):
        text(f"{x} m", (x + 10, -1490, 0), 30, ref)
    text("Grid: thin lines every 100 m, thick lines every 1 km", (-2480, 1520, 0), 40, ref)

    # --- Car and other size references next to the start ---
    def box(name, size, loc, color):
        bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
        o = bpy.context.object
        o.name = name
        o.scale = size
        bpy.ops.object.transform_apply(scale=True)
        o.data.materials.append(mat(name, color))
        o.color = color
        move_to(o, ref)
        return o

    sx, sy = -300.0, -385.0
    box("Car 4.5 x 1.8 m", (4.5, 1.8, 1.3), (sx, sy, 0.65), (0.9, 0.1, 0.1, 1))
    box("House 10 x 10 x 7 m", (10, 10, 7), (sx + 40, sy - 20, 3.5), (0.8, 0.7, 0.5, 1))
    box("Grandstand 60 x 15 x 12 m", (60, 15, 12), (sx + 120, sy - 30, 6), (0.4, 0.4, 0.8, 1))
    bpy.ops.mesh.primitive_cone_add(radius1=3, depth=12, location=(sx - 30, sy - 15, 6))
    t = bpy.context.object
    t.name = "Tree 12 m"
    t.data.materials.append(mat("Tree", (0.1, 0.5, 0.1, 1)))
    move_to(t, ref)
    text("car 4.5 m   house 10 m   grandstand 60 m   tree 12 m", (sx - 40, sy - 60, 0), 6, ref)

    # --- Your track: the sample track's 45 points as a closed line (edges only) ---
    pts = []
    with open(csv_path, encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row or row[0].startswith("x") or row[0].startswith("#"):
                continue
            pts.append([float(v) for v in row])
    me = bpy.data.meshes.new("Track")
    bm = bmesh.new()
    vs = [bm.verts.new((p[0], p[1], p[2])) for p in pts]
    for i in range(len(vs)):
        bm.edges.new((vs[i], vs[(i + 1) % len(vs)]))
    bm.to_mesh(me)
    wa = me.attributes.new("_width", 'FLOAT', 'POINT')
    ba = me.attributes.new("_bank", 'FLOAT', 'POINT')
    for i, p in enumerate(pts):
        wa.data[i].value = p[3] if len(p) > 3 else 12.0
        ba.data[i].value = p[4] if len(p) > 4 else 0.0
    track = bpy.data.objects.new("Track", me)
    track.color = (1, 0.6, 0, 1)
    yours.objects.link(track)

    start = bpy.data.objects.new("Start", None)
    start.empty_display_type = 'SINGLE_ARROW'
    start.empty_display_size = 30
    start.location = (pts[0][0], pts[0][1], pts[0][2])
    start.rotation_euler = (math.radians(90), 0, math.radians(-90))  # arrow lying flat along +x (the drive direction)
    yours.objects.link(start)
    text("START", (pts[0][0] - 20, pts[0][1] + 15, 0), 15, yours).hide_select = True

    home = bpy.data.objects.new("Place_Home", None)
    home.empty_display_type = 'SINGLE_ARROW'
    home.empty_display_size = 25
    home.location = (pts[0][0] + 120, pts[0][1] - 40, 0)
    yours.objects.link(home)

    # --- The quick guide as a text block ---
    guide = bpy.data.texts.new("READ ME FIRST")
    with open(guide_path, encoding="utf-8") as f:
        guide.write(f.read())

    # --- Views: top view, orthographic, far clipping so kilometres are visible ---
    for scr in bpy.data.screens:
        for area in scr.areas:
            if area.type == 'VIEW_3D':
                for sp in area.spaces:
                    if sp.type == 'VIEW_3D':
                        sp.clip_start = 0.1
                        sp.clip_end = 100000
                        sp.shading.color_type = 'OBJECT'
                        sp.overlay.grid_scale = 1.0
                        r = sp.region_3d
                        r.view_perspective = 'ORTHO'
                        r.view_rotation = mathutils.Quaternion((1, 0, 0, 0))
                        r.view_location = (-400, 0, 0)
                        r.view_distance = 2600
    sc.cursor.location = (0, 0, 0)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    track.select_set(True)
    bpy.context.view_layer.objects.active = track
    bpy.ops.wm.save_as_mainfile(filepath=out, compress=True)
    print("STARTER SAVED", out, "laguna size", round(lag_w), round(lag_h))


if __name__ == "__main__":
    a = sys.argv[sys.argv.index("--") + 1:]
    build(a[0], a[1], a[2], a[3])
