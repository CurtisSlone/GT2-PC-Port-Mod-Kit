# Blender is mesh only (the project's rule): nothing of the game's assets goes into a .blend. After a GT2 course's glTF
# is imported, every image it brought is removed and each material keeps only its NAME (the asset reference the
# compiler resolves from the player's install) with a flat colour derived from that name, for telling them apart.
import zlib

import bpy


def name_colour(name):
    """A stable, mid-bright colour for a material name (same name, same colour, in every file)."""
    h = zlib.crc32(name.encode())
    return (0.25 + 0.6 * ((h & 0xFF) / 255), 0.25 + 0.6 * (((h >> 8) & 0xFF) / 255),
            0.25 + 0.6 * (((h >> 16) & 0xFF) / 255), 1.0)


def strip_assets(images_before, materials_before):
    """Drop the images imported since `images_before` and make the materials imported since `materials_before`
    flat-coloured, name-only slots."""
    for m in bpy.data.materials:
        if m in materials_before:
            continue
        rgba = name_colour(m.name)
        m.diffuse_color = rgba
        if m.use_nodes and m.node_tree:
            nodes = m.node_tree.nodes
            for n in [n for n in nodes if n.type == 'TEX_IMAGE']:
                nodes.remove(n)
            for n in nodes:
                if n.type == 'BSDF_PRINCIPLED':
                    n.inputs['Base Color'].default_value = rgba
    for img in [i for i in bpy.data.images if i not in images_before]:
        bpy.data.images.remove(img)
