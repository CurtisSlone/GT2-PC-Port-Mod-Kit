# GT2 Track Tools: the "GT2" tab in the 3D view's sidebar (press N with the mouse over the 3D view).
#
# This add-on is the only Python the release ships. It holds no GT2 data: everything GT2-derived (the starter
# scene with Laguna Seca, courses opened for reference) is generated on the player's machine from the data their
# own disc installed into the port folder, by the port's own tools (gt2-course, gt2-trackc).
#
# * Create starter project: gt2-course exports laguna2 to a temporary folder, a background Blender builds the
#   starter scene from it (starter.py) and saves it where the player chose.
# * Build track for GT2: exports Track + Start + Place_* to track.glb next to the .blend, writes track.json,
#   compiles it with gt2-trackc into the mod MyTrack, installs that into <port>/mods and turns the other course
#   mods off in load-order.txt (the behaviour of the old gt2_tools.py text block, unchanged).
# * Open a GT2 course for reference: exports any course by name and imports its glTF view into the open file.
#
# Test overrides (environment): GT2_RUNTIME (the port folder), GT2_COURSE and GT2_TRACKC (the two tools),
# GT2_DATA (the gt2vol folder). They win over the preferences so headless tests can point at Linux builds.

import json
import os
import shutil
import subprocess
import tempfile

import bpy

from . import course_edit
from . import meshonly

# Legacy add-on metadata (Blender before 4.2, or "Install from Disk" of the zip as an old-style add-on).
# Blender 4.2+ extensions read blender_manifest.toml instead.
bl_info = {
    "name": "GT2 Track Tools",
    "author": "PSX Runtime project",
    "version": (0, 3, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar (N) > GT2",
    "description": "Make GT2 tracks: starter project from your own GT2 data, build and install the track mod",
    "category": "Import-Export",
}

HERE = os.path.dirname(os.path.abspath(__file__))
MOD = "MyTrack"
COURSE = "zz_mytrack"
# Mods that carry their own course list (.crsinfo): only one of them works at a time.
COURSE_MODS = ["SampleTrack", "X3Course", "TrackOval", "TrackBankedOval", "TrackFigure8", "TrackRoadCourse",
               "MySketch", MOD]


# ---------------------------------------------------------------------------------------------------------------
# Port folder and tools


def prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except (KeyError, AttributeError):
        return None


def blend_dir():
    return bpy.path.abspath("//")


def port_dir():
    """The release folder (psx-play, gt2-course, gt2-trackc, data, mods).

    Environment first (tests), then the preference. With neither, the folder above the .blend's folder: the old
    starter lived in <port>/custom, and files saved there keep working without setting the preference."""
    env = os.environ.get("GT2_RUNTIME")
    if env:
        return env
    p = prefs()
    if p is not None and p.port_folder.strip():
        return bpy.path.abspath(p.port_folder.strip())
    if bpy.data.filepath:
        return os.path.dirname(os.path.normpath(blend_dir()))
    return ""


def tool_path(port, name, env):
    """A port tool: the env override, else <port>/<name>.exe (Windows release), else <port>/<name>."""
    if os.environ.get(env):
        return os.environ[env]
    for n in (name + ".exe", name):
        p = os.path.join(port, n)
        if os.path.isfile(p):
            return p
    return os.path.join(port, name + ".exe")


def data_path(port):
    return os.environ.get("GT2_DATA") or os.path.join(port, "data", "gt2vol")


def check_port(port, need=("gt2-course", "gt2-trackc")):
    """Problems with the port folder as short sentences; empty when it is usable."""
    if not port:
        return ["Set the port folder: Edit > Preferences > Add-ons > GT2 Track Tools"]
    if not os.path.isdir(port):
        return [f"Port folder not found: {port}"]
    out = []
    for n, env in (("gt2-course", "GT2_COURSE"), ("gt2-trackc", "GT2_TRACKC")):
        if n in need and not os.path.isfile(tool_path(port, n, env)):
            out.append(f"{n}.exe is not in the port folder")
    if not os.path.isdir(data_path(port)):
        out.append("data\\gt2vol is missing: install GT2 from your disc first")
    return out


def run(cmd, timeout=900):
    """Run a tool without a console window popping up on Windows; returns (exit code, all output)."""
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NO_WINDOW
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def last_problem(log):
    lines = [l for l in log.splitlines() if l.strip()]
    problems = [l for l in lines if "error" in l.lower() or "warning" in l.lower()]
    return problems[-1] if problems else (lines[-1] if lines else "unknown error")


def export_course(port, course, out):
    """gt2-course export COURSE into OUT; returns (glTF path or None, log)."""
    exe = tool_path(port, "gt2-course", "GT2_COURSE")
    code, log = run([exe, "export", course, "--data", data_path(port), "--out", out])
    gltf = os.path.join(out, "view", course + ".gltf")
    if code != 0 or not os.path.isfile(gltf):
        return None, log
    return gltf, log


# ---------------------------------------------------------------------------------------------------------------
# Track helpers (from gt2_tools.py)


def track_length(obj):
    if obj is None or obj.type != 'MESH':
        return 0.0
    m = obj.matrix_world
    vs = [m @ v.co for v in obj.data.vertices]
    return sum((vs[e.vertices[0]] - vs[e.vertices[1]]).length for e in obj.data.edges)


def set_load_order(mods_dir):
    path = os.path.join(mods_dir, "load-order.txt")
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lines = [l.rstrip("\r\n") for l in f]
    out, seen = [], False
    for l in lines:
        name = l.lstrip("#").strip()
        if name == MOD:
            out.append(MOD)
            seen = True
        elif name in COURSE_MODS and not l.startswith("#"):
            out.append("#" + name)
        else:
            out.append(l)
    if not seen:
        out.append(MOD)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(out) + "\n")


# ---------------------------------------------------------------------------------------------------------------
# Preferences


class GT2TOOLS_AP_prefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    port_folder: bpy.props.StringProperty(
        name="Port folder", subtype='DIR_PATH',
        description="The GT2 port folder: the one with psx-play.exe, gt2-course.exe, gt2-trackc.exe, data and mods")

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "port_folder")
        port = port_dir()
        problems = check_port(port)
        if problems:
            for p in problems:
                lay.label(text=p, icon='ERROR')
        else:
            lay.label(text="Port folder OK: gt2-course, gt2-trackc and your GT2 data found", icon='CHECKMARK')


# ---------------------------------------------------------------------------------------------------------------
# Operators


class GT2TOOLS_OT_create_starter(bpy.types.Operator):
    """Make a starter .blend from your own GT2 data: grid, Laguna Seca at true size, size references and a sample road"""
    bl_idname = "gt2tools.create_starter"
    bl_label = "Create starter project"

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.blend", options={'HIDDEN'})
    open_after: bpy.props.BoolProperty(name="Open it when done", default=True)

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = "GT2_Track_Starter.blend"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        out = bpy.path.abspath(self.filepath)
        if not out.lower().endswith(".blend"):
            out += ".blend"
        port = port_dir()
        problems = check_port(port, need=("gt2-course",))
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        tmp = tempfile.mkdtemp(prefix="gt2-starter-")
        try:
            gltf, log = export_course(port, "laguna2", os.path.join(tmp, "laguna"))
            if gltf is None:
                self.report({'ERROR'}, f"gt2-course could not export Laguna Seca: {last_problem(log)}")
                return {'CANCELLED'}
            # A second Blender builds and saves the scene, so the open file and its undo history stay as they are.
            cmd = [bpy.app.binary_path, "-b", "--factory-startup", "--python-exit-code", "1",
                   "--python", os.path.join(HERE, "starter.py"), "--",
                   gltf, os.path.join(HERE, "sample_track.csv"), os.path.join(HERE, "QUICKSTART.txt"), out]
            code, log = run(cmd)
            if code != 0 or not os.path.isfile(out):
                logf = os.path.splitext(out)[0] + "-log.txt"
                with open(logf, "w", encoding="utf-8") as f:
                    f.write(log)
                self.report({'ERROR'}, f"Building the starter failed: {last_problem(log)}  (all of it: {logf})")
                return {'CANCELLED'}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        if self.open_after and not bpy.app.background:
            if bpy.data.is_dirty:
                self.report({'WARNING'}, f"Saved {out}. Your open file has unsaved changes: open the starter "
                                         "with File > Open when ready")
                return {'FINISHED'}
            bpy.ops.wm.open_mainfile(filepath=out)
        self.report({'INFO'}, f"Starter project saved: {out}")
        return {'FINISHED'}


class GT2TOOLS_OT_build(bpy.types.Operator):
    """Export the Track, compile it for GT2 and install it as the MyTrack mod"""
    bl_idname = "gt2tools.build_track"
    bl_label = "Build track for GT2"

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the track files are written next to it")
            return {'CANCELLED'}
        track = bpy.data.objects.get("Track")
        if track is None or track.type != 'MESH':
            self.report({'ERROR'}, "There is no object named Track (a line of points). Rename your road to Track")
            return {'CANCELLED'}
        if len(track.data.polygons) > 0:
            self.report({'ERROR'}, "Track has faces. It must be a line of points only (edges, no faces)")
            return {'CANCELLED'}
        rt = port_dir()
        problems = check_port(rt, need=("gt2-trackc",))
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        exe = tool_path(rt, "gt2-trackc", "GT2_TRACKC")
        data = data_path(rt)
        mods = os.path.join(rt, "mods")
        cd = blend_dir()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        # Export only the track, the start marker and the place markers.
        for o in context.view_layer.objects:
            o.select_set(o.name == "Track" or o.name == "Start" or o.name.startswith("Place_"))
        glb = os.path.join(cd, "track.glb")
        bpy.ops.export_scene.gltf(filepath=glb, export_format='GLB', use_selection=True, export_yup=True,
                                  export_apply=True, export_attributes=True, use_mesh_edges=True,
                                  use_mesh_vertices=False, export_materials='NONE', export_animations=False)
        name = context.scene.gt2_track_name.strip() or "My Track"
        spec = os.path.join(cd, "track.json")
        js = {}
        if os.path.exists(spec):
            try:
                with open(spec, encoding="utf-8") as f:
                    js = json.load(f)
            except Exception:
                js = {}
        js.setdefault("import", "track.glb")
        js["name"] = name
        js["add"] = COURSE
        ci = js.setdefault("course_info", {})
        ci["display_name"] = name
        ci.setdefault("sky_from", "laguna2")
        with open(spec, "w", encoding="utf-8") as f:
            json.dump(js, f, indent=2)
        out = os.path.join(cd, "out", "mytrack")
        cmd = [exe, "compile", spec, "--out", out, "--data", data, "--mod", MOD]
        try:
            code, log = run(cmd, timeout=600)
        except Exception as e:
            self.report({'ERROR'}, f"could not run gt2-trackc: {e}")
            return {'CANCELLED'}
        with open(os.path.join(cd, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        lines = [l for l in log.splitlines() if l.strip()]
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: build-log.txt "
                                   "next to this .blend)")
            return {'CANCELLED'}
        src = os.path.join(out, "mods", MOD)
        dst = os.path.join(mods, MOD)
        os.makedirs(mods, exist_ok=True)
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
        set_load_order(mods)
        km = track_length(track) / 1000.0
        summary = next((l for l in reversed(lines) if "errors" in l), "built")
        self.report({'INFO'}, f"Built \"{name}\" ({km:.2f} km): {summary}. Start play-mytrack.bat")
        return {'FINISHED'}


_courses = []


def course_items(self, context):
    """The disc's course names from `gt2-course list` (asked once per session; the list never changes)."""
    if not _courses:
        port = port_dir()
        if not check_port(port, need=("gt2-course",)):
            try:
                code, log = run([tool_path(port, "gt2-course", "GT2_COURSE"), "list", "--data", data_path(port)],
                                timeout=60)
                for l in log.splitlines():
                    parts = l.split()
                    if code == 0 and len(parts) == 2 and parts[0].isdigit():
                        _courses.append((parts[1], parts[1], ""))
            except Exception:
                pass
    return _courses or [("laguna2", "laguna2", "")]


class GT2TOOLS_OT_import_course(bpy.types.Operator):
    """Export a GT2 course from your data and add it to this file as a reference (true size, mesh only, no textures)"""
    bl_idname = "gt2tools.import_course"
    bl_label = "Add GT2 course"

    course: bpy.props.StringProperty(name="Course", default="laguna2")

    def execute(self, context):
        port = port_dir()
        problems = check_port(port, need=("gt2-course",))
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        course = self.course.strip()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        tmp = tempfile.mkdtemp(prefix="gt2-course-")
        try:
            gltf, log = export_course(port, course, os.path.join(tmp, course))
            if gltf is None:
                self.report({'ERROR'}, f"gt2-course could not export {course}: {last_problem(log)}")
                return {'CANCELLED'}
            objs, imgs, mats = set(bpy.data.objects), set(bpy.data.images), set(bpy.data.materials)
            bpy.ops.import_scene.gltf(filepath=gltf)
            # Mesh only: no game textures in the .blend; materials keep their names (the asset references).
            meshonly.strip_assets(imgs, mats)
            col = bpy.data.collections.new(f"GT2 course {course} (reference, not exported)")
            context.scene.collection.children.link(col)
            col.color_tag = 'COLOR_04'
            for o in bpy.data.objects:
                if o not in objs:
                    for c in list(o.users_collection):
                        c.objects.unlink(o)
                    col.objects.link(o)
                    # Same layers hidden as in the starter: low detail, collision, AI lines.
                    n = o.name.lower()
                    if any(w in n for w in ("track_low", "collision", "ai line", "ai_line")):
                        o.hide_set(True)
                        o.hide_render = True
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        self.report({'INFO'}, f"Added {course} (move it with its top empty; it is never exported with your track)")
        return {'FINISHED'}


class GT2TOOLS_OT_add_place(bpy.types.Operator):
    """Add a place marker at the 3D cursor (where you last clicked)"""
    bl_idname = "gt2tools.add_place"
    bl_label = "Add place marker"
    kind: bpy.props.EnumProperty(items=[("Home", "Home", ""), ("Dealer", "Dealer", ""), ("Race", "Race", ""),
                                        ("License", "License", ""), ("Place", "Other", "")])

    def execute(self, context):
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.empty_add(type='SINGLE_ARROW', location=context.scene.cursor.location)
        o = context.object
        o.name = f"Place_{self.kind}"
        o.empty_display_size = 25
        col = bpy.data.collections.get("YOUR TRACK")
        if col and o.name not in col.objects:
            for c in o.users_collection:
                c.objects.unlink(o)
            col.objects.link(o)
        return {'FINISHED'}


# ---------------------------------------------------------------------------------------------------------------
# Panel


class GT2TOOLS_PT_panel(bpy.types.Panel):
    bl_label = "GT2 Track"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"

    def draw(self, context):
        lay = self.layout
        port = port_dir()
        problems = check_port(port)
        if problems:
            box = lay.box()
            for p in problems:
                box.label(text=p, icon='ERROR')
        lay.operator("gt2tools.create_starter", icon='FILE_NEW')
        lay.separator()
        track = bpy.data.objects.get("Track")
        lay.prop(context.scene, "gt2_track_name", text="Name")
        if track is not None and track.type == 'MESH':
            lay.label(text=f"Track length: {track_length(track) / 1000.0:.2f} km, {len(track.data.vertices)} points")
        else:
            lay.label(text="No object named Track", icon='ERROR')
        lay.operator("gt2tools.build_track", icon='AUTO')
        lay.separator()
        lay.label(text="Place markers (at the 3D cursor):")
        row = lay.row(align=True)
        for k in ("Home", "Dealer", "Race", "License"):
            row.operator("gt2tools.add_place", text=k).kind = k
        lay.separator()
        lay.label(text="GT2 course for reference:")
        row = lay.row(align=True)
        row.prop(context.window_manager, "gt2_course", text="")
        row.operator("gt2tools.import_course", text="Add", icon='IMPORT').course = context.window_manager.gt2_course
        lay.separator()
        box = lay.box()
        box.label(text="1 grid square = 1 m. Car = 4.5 m long.")
        box.label(text="Roads: 10-20 m wide. Laguna Seca = 3.6 km.")
        box.label(text="Edit the road: select Track, Tab, move points (G).")


classes = (GT2TOOLS_AP_prefs, GT2TOOLS_OT_create_starter, GT2TOOLS_OT_build, GT2TOOLS_OT_import_course,
           GT2TOOLS_OT_add_place, GT2TOOLS_PT_panel)


def register():
    bpy.types.Scene.gt2_track_name = bpy.props.StringProperty(name="Track name", default="My Track")
    bpy.types.WindowManager.gt2_course = bpy.props.EnumProperty(name="Course", items=course_items)
    for c in classes + course_edit.classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes + course_edit.classes):
        bpy.utils.unregister_class(c)
    del bpy.types.WindowManager.gt2_course
    del bpy.types.Scene.gt2_track_name
