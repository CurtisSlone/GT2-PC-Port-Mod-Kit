# Edit an existing GT2 course's mesh and compile it back (docs/gt2/COURSE-EDIT.md).
#
# * "Edit GT2 course": `gt2-course export COURSE --edit` writes a mesh-only glTF (no images, no textures, not even
#   links: the project's rule is that Blender holds no game assets). This module reads it itself, not through
#   Blender's glTF importer, so that the mesh is editable: vertices shared between faces (and between sections)
#   are welded, quads stay quads, and the face facts live in face/corner attributes:
#     face   _GT2_SEC (section + 1, +32768 low mesh), _GT2_FACE (1 + list*65536 + index), _GT2_CODE, _GT2_SURF,
#            _GT2_SHADE, _GT2_ZONE, _GT2_SORT, _GT2_CULL, _GT2_COLL
#     corner _GT2_CORNER (the stored corner), _GT2_RGB (its colour 0xBBGGRR)
#   Materials are names only: `tex:NNNN` (the course's texture-table entry, resolved from the player's install at
#   build time) or `untex`, shown in a flat colour derived from the name (meshonly.py). New faces need one of
#   these names (or a surface name: tarmac, kerb, grass, gravel, offroad, dirt) or the build stops and says where.
# * "Build edited course": Blender's own glTF exporter writes the two objects with their attributes (it splits
#   vertices by attribute and triangulates; the compiler puts the faces back together from _GT2_FACE and
#   _GT2_CORNER), then `gt2-scenec course` compiles it against the original course into a mods folder.
#
# The functions at the top use bpy only, so headless gate scripts can call them too.

import json
import os
import shutil
import struct

import bpy
import numpy as np

from . import meshonly

FACE_ATTRS = ["_GT2_SEC", "_GT2_FACE", "_GT2_CODE", "_GT2_SURF", "_GT2_SHADE", "_GT2_ZONE", "_GT2_SORT",
              "_GT2_CULL", "_GT2_COLL"]
CORNER_ATTRS = ["_GT2_CORNER", "_GT2_RGB"]
LOW = 32768
COLLECTION_PROP = "gt2_edit_course"


# ---------------------------------------------------------------------------------------------------------------
# glTF reading (only what our files and Blender's exporter use)

_CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
_NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:4] != b"glTF":
        raise ValueError(f"{path}: not a .glb file")
    off, gl, binc = 12, None, b""
    while off + 8 <= len(data):
        ln, ty = struct.unpack_from("<II", data, off)
        chunk = data[off + 8:off + 8 + ln]
        if ty == 0x4E4F534A:
            gl = json.loads(chunk.decode("utf-8"))
        elif ty == 0x004E4942:
            binc = chunk
        off += 8 + ln
    return gl, binc


def accessor(gl, binc, k):
    """Accessor k as a (count, components) float64 array."""
    a = gl["accessors"][k]
    v = gl["bufferViews"][a["bufferView"]]
    dt = np.dtype(_CT[a["componentType"]])
    n = _NC[a["type"]]
    count = a["count"]
    if count == 0:
        return np.zeros((0, n))
    off = v.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = v.get("byteStride", 0) or dt.itemsize * n
    if stride == dt.itemsize * n:
        arr = np.frombuffer(binc, dtype=dt, count=count * n, offset=off).reshape(count, n)
    else:
        rows = np.frombuffer(binc, dtype=np.uint8, count=stride * (count - 1) + dt.itemsize * n, offset=off)
        sel = np.arange(count)[:, None] * stride + np.arange(dt.itemsize * n)[None, :]
        arr = rows[sel].copy().view(dt).reshape(count, n)
    return arr.astype(np.float64)


def _node_matrix(nd):
    if "matrix" in nd:
        return np.array(nd["matrix"], dtype=np.float64).reshape(4, 4).T
    t = nd.get("translation", [0, 0, 0])
    r = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    x, y, z, w = r
    rot = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                    [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                    [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    m = np.eye(4)
    m[:3, :3] = rot * np.array(s)[None, :]
    m[:3, 3] = t
    return m


def _walk(gl, k, parent, out):
    nd = gl["nodes"][k]
    m = parent @ _node_matrix(nd)
    if "mesh" in nd:
        out.append((nd.get("name", f"node{k}"), nd["mesh"], m))
    for c in nd.get("children", []):
        _walk(gl, c, m, out)


def mesh_nodes(gl):
    out = []
    scene = gl.get("scenes", [{}])[gl.get("scene", 0)]
    for k in scene.get("nodes", range(len(gl.get("nodes", [])))):
        _walk(gl, k, np.eye(4), out)
    return out


# ---------------------------------------------------------------------------------------------------------------
# Import: edit glTF -> welded Blender meshes with face/corner attributes


def _faces_of(gl, binc, mesh_index, m):
    """(positions in course metres, per-vertex attribute dict, faces): faces = [(material name, [vertex ids in
    corner order])], one per GT2 face (put back together by _GT2_SEC/_GT2_FACE/_GT2_CORNER) or per new
    triangle."""
    pos_all, attr_all, faces = [], {a: [] for a in FACE_ATTRS + CORNER_ATTRS}, []
    base = 0
    for prim in gl["meshes"][mesh_index]["primitives"]:
        if prim.get("mode", 4) != 4 or "indices" not in prim:
            continue
        mat = gl["materials"][prim["material"]].get("name", "") if "material" in prim else ""
        p = accessor(gl, binc, prim["attributes"]["POSITION"])
        p = (np.c_[p, np.ones(len(p))] @ m.T)[:, :3]
        n = len(p)
        attrs = {}
        for a in FACE_ATTRS + CORNER_ATTRS:
            k = prim["attributes"].get(a)
            attrs[a] = accessor(gl, binc, k)[:, 0].round().astype(np.int64) if k is not None else np.zeros(n, np.int64)
            attr_all[a].append(attrs[a])
        pos_all.append(p)
        idx = accessor(gl, binc, prim["indices"])[:, 0].astype(np.int64).reshape(-1, 3)
        groups = {}
        order = []
        for t in idx:
            sec, fid = attrs["_GT2_SEC"][t[0]], attrs["_GT2_FACE"][t[0]]
            if fid <= 0 or sec <= 0:
                faces.append((mat, [int(base + q) for q in t]))
                continue
            key = (int(sec), int(fid))
            g = groups.get(key)
            if g is None:
                g = groups[key] = {}
                order.append(key)
            for q in t:
                g.setdefault(int(attrs["_GT2_CORNER"][q]), []).append(int(base + q))
        for key in order:
            g = groups[key]
            ok = all(len({tuple(np.round(pos_all[-1][v - base], 6)) for v in vs}) == 1 for vs in g.values())
            if ok and len(g) >= 3:
                faces.append((mat, [g[c][0] for c in sorted(g)]))
            else:
                # Two faces with one id (an editor copy) or a face missing corners: keep its triangles as
                # separate faces (the compiler sorts out which one keeps the id).
                tri = [t for t in idx if (attrs["_GT2_SEC"][t[0]], attrs["_GT2_FACE"][t[0]]) == key]
                for t in tri:
                    faces.append((mat, [int(base + q) for q in t]))
        base += n
    if not pos_all:
        return np.zeros((0, 3)), {a: np.zeros(0, np.int64) for a in attr_all}, []
    return np.vstack(pos_all), {a: np.concatenate(v) for a, v in attr_all.items()}, faces


def _material(name):
    m = bpy.data.materials.get(name)
    if m is None:
        m = bpy.data.materials.new(name)
        m.diffuse_color = meshonly.name_colour(name)
    return m


def build_object(name, pos, attrs, faces):
    """A Blender mesh object: course metres (glTF y-up) -> Blender z-up (x, -z, y); equal positions welded,
    except where one face would use a vertex twice (degenerate faces keep their own corners)."""
    bpos = np.c_[pos[:, 0], -pos[:, 2], pos[:, 1]].astype(np.float32)
    weld = {}
    verts = []
    loops_v, loops_src, poly_start, poly_total, poly_mat, poly_src = [], [], [], [], [], []
    mats = {}
    seen = set()
    for mat, vs in faces:
        keys = [bpos[v].tobytes() for v in vs]
        # A face over the same corners as an earlier one (the two sides of a double-sided wall) gets vertices of
        # its own: Blender's mesh validation (which the glTF exporter runs) deletes duplicate faces.
        twin = frozenset(keys) in seen
        seen.add(frozenset(keys))
        used = set()
        poly_start.append(len(loops_v))
        poly_total.append(len(vs))
        for v, key in zip(vs, keys):
            bi = None if twin else weld.get(key)
            if bi is None or bi in used:
                bi = len(verts)
                verts.append(bpos[v])
                if key not in weld:
                    weld[key] = bi
            used.add(bi)
            loops_v.append(bi)
            loops_src.append(v)
        poly_mat.append(mats.setdefault(mat, len(mats)))
        poly_src.append(vs[0])
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(verts))
    if verts:
        me.vertices.foreach_set("co", np.array(verts, dtype=np.float32).ravel())
    me.loops.add(len(loops_v))
    me.loops.foreach_set("vertex_index", np.array(loops_v, dtype=np.int32))
    me.polygons.add(len(poly_start))
    me.polygons.foreach_set("loop_start", np.array(poly_start, dtype=np.int32))
    me.polygons.foreach_set("loop_total", np.array(poly_total, dtype=np.int32))
    me.polygons.foreach_set("material_index", np.array(poly_mat, dtype=np.int32))
    me.update(calc_edges=True)
    for mat in sorted(mats, key=mats.get):
        me.materials.append(_material(mat or "untex"))
    ps = np.array(poly_src, dtype=np.int64)
    ls = np.array(loops_src, dtype=np.int64)
    for a in FACE_ATTRS:
        at = me.attributes.new(a, 'INT', 'FACE')
        at.data.foreach_set("value", attrs[a][ps].astype(np.int32) if len(ps) else np.zeros(0, np.int32))
    for a in CORNER_ATTRS:
        at = me.attributes.new(a, 'INT', 'CORNER')
        at.data.foreach_set("value", attrs[a][ls].astype(np.int32) if len(ls) else np.zeros(0, np.int32))
    ob = bpy.data.objects.new(name, me)
    return ob


def import_edit(path, course=None, collection=None):
    """Read an edit glTF (ours, or one Blender exported from an edit) into a collection; returns it."""
    gl, binc = read_glb(path)
    if course is None:
        course = gl.get("asset", {}).get("extras", {}).get("gt2_edit", {}).get("course") or \
            os.path.basename(path).split(".")[0]
    col = collection or bpy.data.collections.new(f"GT2 edit {course}")
    if collection is None:
        bpy.context.scene.collection.children.link(col)
    col[COLLECTION_PROP] = course
    for node_name, mi, m in mesh_nodes(gl):
        pos, attrs, faces = _faces_of(gl, binc, mi, m)
        if not faces:
            continue
        low = "low" in node_name.lower()
        ob = build_object("gt2_track_low" if low else "gt2_track", pos, attrs, faces)
        ob["gt2_mesh"] = "low" if low else "high"
        col.objects.link(ob)
        if low:
            ob.hide_set(True)
    return col


def edit_objects(col):
    return [o for o in col.all_objects if o.type == 'MESH' and o.get("gt2_mesh") in ("high", "low")]


def export_edit(col, path):
    """Blender's glTF exporter on the collection's two meshes, with the _GT2_* attributes; no images (the
    materials hold no image nodes) and no normals or UVs (the compiler takes neither)."""
    obs = edit_objects(col)
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    hidden = []
    for o in obs:
        if o.hide_get():
            hidden.append(o)
            o.hide_set(False)
        o.select_set(True)
    try:
        bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_yup=True,
                                  export_apply=False, export_attributes=True, export_normals=False,
                                  export_texcoords=False, export_tangents=False, export_materials='EXPORT',
                                  export_vertex_color='NONE', export_animations=False, export_skins=False,
                                  export_morph=False, export_cameras=False, export_lights=False,
                                  export_extras=False)
    finally:
        for o in hidden:
            o.hide_set(True)
    return path


# ---------------------------------------------------------------------------------------------------------------
# Operators (the add-on's GT2 tab)


def _tools():
    from . import check_port, data_path, port_dir, run, tool_path, last_problem
    return check_port, data_path, port_dir, run, tool_path, last_problem


def _edit_collection(context):
    for c in bpy.data.collections:
        if COLLECTION_PROP in c and edit_objects(c):
            if context.collection is c or any(o in c.all_objects.values() for o in context.selected_objects):
                return c
    for c in bpy.data.collections:
        if COLLECTION_PROP in c and edit_objects(c):
            return c
    return None


class GT2TOOLS_OT_edit_course(bpy.types.Operator):
    """Open a GT2 course from your own data for editing: mesh only (no textures), faces keep their ids and asset names"""
    bl_idname = "gt2tools.edit_course"
    bl_label = "Edit GT2 course"

    course: bpy.props.StringProperty(name="Course", default="laguna")

    def execute(self, context):
        check_port, data_path, port_dir, run, tool_path, last_problem = _tools()
        port = port_dir()
        problems = check_port(port, need=("gt2-course",))
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        course = self.course.strip()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        work = os.path.join(bpy.path.abspath("//") if bpy.data.filepath else bpy.app.tempdir, "gt2-edit")
        os.makedirs(work, exist_ok=True)
        code, log = run([tool_path(port, "gt2-course", "GT2_COURSE"), "export", course, "--edit", "--data",
                         data_path(port), "--out", work])
        glb = os.path.join(work, course + ".edit.glb")
        if code != 0 or not os.path.isfile(glb):
            self.report({'ERROR'}, f"gt2-course could not export {course}: {last_problem(log)}")
            return {'CANCELLED'}
        col = import_edit(glb, course)
        # The export is game-derived geometry: it stays on this machine, next to the .blend (or in temp).
        self.report({'INFO'}, f"{course}: {sum(len(o.data.polygons) for o in edit_objects(col))} faces to edit "
                              "(gt2_track; the mirror's gt2_track_low is hidden)")
        return {'FINISHED'}


class GT2TOOLS_OT_build_edited(bpy.types.Operator):
    """Compile the edited course against the original from your data and install it as a mod"""
    bl_idname = "gt2tools.build_edited_course"
    bl_label = "Build edited course"

    as_new: bpy.props.StringProperty(name="As new course", default="",
                                     description="Empty: replace the course. A name: add it as a new course")

    def execute(self, context):
        check_port, data_path, port_dir, run, tool_path, last_problem = _tools()
        port = port_dir()
        problems = check_port(port, need=("gt2-course",))
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the build files are written next to it")
            return {'CANCELLED'}
        col = _edit_collection(context)
        if col is None:
            self.report({'ERROR'}, "No GT2 course to build: use Edit GT2 course first")
            return {'CANCELLED'}
        scenec = tool_path(port, "gt2-scenec", "GT2_SCENEC")
        if not os.path.isfile(scenec):
            self.report({'ERROR'}, "gt2-scenec.exe is not in the port folder")
            return {'CANCELLED'}
        course = col[COLLECTION_PROP]
        cd = bpy.path.abspath("//")
        glb = export_edit(col, os.path.join(cd, f"{course}.edited.glb"))
        out = os.path.join(cd, "out", f"{course}-edit")
        modname = f"Edit_{course}"
        cmd = [scenec, "course", "--original", data_path(port), "--course",
               course, "--edited", glb, "--out", out, "--mod", modname,
               "--patch-out", os.path.join(cd, f"{course}.gt2patch")]
        if self.as_new.strip():
            cmd += ["--add", self.as_new.strip()]
        code, log = run(cmd, timeout=900)
        with open(os.path.join(cd, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: build-log.txt)")
            return {'CANCELLED'}
        mods = os.path.join(port, "mods")
        src = os.path.join(out, "mods", modname)
        dst = os.path.join(mods, modname)
        os.makedirs(mods, exist_ok=True)
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
        enable_mod(mods, modname)
        lines = [l for l in log.splitlines() if l.strip()]
        self.report({'INFO'}, f"Built {course}: {lines[-1] if lines else 'done'} (mod {modname}; share "
                              f"{course}.gt2patch, never the .blend; on in mods\\load-order.txt)")
        return {'FINISHED'}


def enable_mod(mods_dir, name):
    """Turn the mod on in load-order.txt (with that file, only the folders it lists load): its line is added at
    the end, or its # removed. Other lines stay as they are."""
    path = os.path.join(mods_dir, "load-order.txt")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        lines = [l.rstrip("\r\n") for l in f]
    out, seen = [], False
    for l in lines:
        if l.lstrip("#").strip() == name:
            if not seen:
                out.append(name)
            seen = True
        else:
            out.append(l)
    if not seen:
        out.append(name)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(out) + "\n")


class GT2TOOLS_PT_course_edit(bpy.types.Panel):
    bl_label = "Edit a GT2 course"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        row = lay.row(align=True)
        row.prop(context.window_manager, "gt2_course", text="")
        row.operator("gt2tools.edit_course", text="Edit", icon='EDITMODE_HLT').course = \
            context.window_manager.gt2_course
        lay.operator("gt2tools.build_edited_course", icon='AUTO')
        box = lay.box()
        box.label(text="Mesh only: materials are names (tex:NNNN).")
        box.label(text="New faces: give them a tex: material.")
        box.label(text="Share the .gt2patch, not the .blend.")


classes = (GT2TOOLS_OT_edit_course, GT2TOOLS_OT_build_edited, GT2TOOLS_PT_course_edit)
