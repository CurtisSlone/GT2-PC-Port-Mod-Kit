# Edit an existing GT2 course's mesh and compile it back (docs/gt2/COURSE-EDIT.md).
#
# * "Edit": `gt2-tools course export COURSE --edit` writes the edit glTF. Without "Show textures" it is mesh only;
#   with it (`--edit --textures`) the course's texture pages, made from the player's install, sit in textures/
#   beside the .glb and the file links them. This module reads the glTF itself, not through Blender's glTF
#   importer, so that the mesh is editable: vertices shared between faces (and between sections) are welded, quads
#   stay quads, and the face facts live in face/corner attributes:
#     face   _GT2_SEC (section + 1, +32768 low mesh), _GT2_FACE (1 + list*65536 + index), _GT2_CODE, _GT2_SURF,
#            _GT2_SHADE, _GT2_ZONE, _GT2_SORT, _GT2_CULL, _GT2_COLL
#     corner _GT2_CORNER (the stored corner), _GT2_RGB (its color 0xBBGGRR)
#   Materials are named `tex:NNNN` (the course's texture-table entry) or `untex`. Mesh only, a material is a flat
#   color derived from the name (meshonly.py). With textures it shows its page through an image LINKED to the
#   file in textures/ (never packed: the pages are game pixels and stay out of the .blend), with the entry's UVs.
# * Texture picker: the course's whole texture table (asset.extras.gt2_edit.textures) is kept on the edit
#   collection; "Apply to selected faces" moves faces to another `tex:NNNN` and rewrites their UVs from that
#   entry's four corner UVs (the compiler reads only the material name; the UVs are for what Blender shows).
# * "Build edited course": Blender's own glTF exporter writes the two objects with their attributes (no UVs, no
#   images), then `gt2-tools edit` compiles it against the original course into a mod and a .gt2patch.
#
# The functions at the top use bpy only, so headless test scripts can call them too.

import json
import os
import shutil
import struct

import bpy
import bpy.utils.previews
import numpy as np

from . import meshonly

FACE_ATTRS = ["_GT2_SEC", "_GT2_FACE", "_GT2_CODE", "_GT2_SURF", "_GT2_SHADE", "_GT2_ZONE", "_GT2_SORT",
              "_GT2_CULL", "_GT2_COLL"]
CORNER_ATTRS = ["_GT2_CORNER", "_GT2_RGB"]
LOW = 32768
COLLECTION_PROP = "gt2_edit_course"
TABLE_PROP = "gt2_textures"          # the course's texture table (JSON text) on the edit collection
PAGES_PROP = "gt2_pages"             # the textures folder (relative to the .blend when it can be)
PAGE_IMAGE = "gt2_page"              # set on every texture page image this add-on links
UV_NAME = "UVMap"
SURFACES = ["tarmac", "kerb", "grass", "gravel", "offroad", "dirt"]


# ---------------------------------------------------------------------------------------------------------------
# glTF reading (only what our files and Blender's exporter use)

_CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
_NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def read_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:4] != b"glTF":
        raise ValueError(f"{path}: not a .glb file")
    off, gl, binc = 12, None, b""
    while off + 8 <= len(data):
        ln, ty = struct.unpack_from("<II", data, off)
        chunk = data[off + 8:off + 8 + ln]
        if ty == 0x4E4F534A:
            gl = json.loads(chunk.decode("utf-8"))
        elif ty == 0x004E4942:
            binc = chunk
        off += 8 + ln
    return gl, binc


def accessor(gl, binc, k):
    """Accessor k as a (count, components) float64 array."""
    a = gl["accessors"][k]
    v = gl["bufferViews"][a["bufferView"]]
    dt = np.dtype(_CT[a["componentType"]])
    n = _NC[a["type"]]
    count = a["count"]
    if count == 0:
        return np.zeros((0, n))
    off = v.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = v.get("byteStride", 0) or dt.itemsize * n
    if stride == dt.itemsize * n:
        arr = np.frombuffer(binc, dtype=dt, count=count * n, offset=off).reshape(count, n)
    else:
        rows = np.frombuffer(binc, dtype=np.uint8, count=stride * (count - 1) + dt.itemsize * n, offset=off)
        sel = np.arange(count)[:, None] * stride + np.arange(dt.itemsize * n)[None, :]
        arr = rows[sel].copy().view(dt).reshape(count, n)
    return arr.astype(np.float64)


def _node_matrix(nd):
    if "matrix" in nd:
        return np.array(nd["matrix"], dtype=np.float64).reshape(4, 4).T
    t = nd.get("translation", [0, 0, 0])
    r = nd.get("rotation", [0, 0, 0, 1])
    s = nd.get("scale", [1, 1, 1])
    x, y, z, w = r
    rot = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                    [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                    [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    m = np.eye(4)
    m[:3, :3] = rot * np.array(s)[None, :]
    m[:3, 3] = t
    return m


def _walk(gl, k, parent, out):
    nd = gl["nodes"][k]
    m = parent @ _node_matrix(nd)
    if "mesh" in nd:
        out.append((nd.get("name", f"node{k}"), nd["mesh"], m))
    for c in nd.get("children", []):
        _walk(gl, c, m, out)


def mesh_nodes(gl):
    out = []
    scene = gl.get("scenes", [{}])[gl.get("scene", 0)]
    for k in scene.get("nodes", range(len(gl.get("nodes", [])))):
        _walk(gl, k, np.eye(4), out)
    return out


# ---------------------------------------------------------------------------------------------------------------
# Import: edit glTF -> welded Blender meshes with face/corner attributes


def _faces_of(gl, binc, mesh_index, m):
    """(positions in course meters, per-vertex attribute dict, per-vertex UVs or None, faces): faces =
    [(material name, [vertex ids in corner order])], one per GT2 face (put back together by
    _GT2_SEC/_GT2_FACE/_GT2_CORNER) or per new triangle."""
    pos_all, uv_all, attr_all, faces = [], [], {a: [] for a in FACE_ATTRS + CORNER_ATTRS}, []
    has_uv = False
    base = 0
    for prim in gl["meshes"][mesh_index]["primitives"]:
        if prim.get("mode", 4) != 4 or "indices" not in prim:
            continue
        mat = gl["materials"][prim["material"]].get("name", "") if "material" in prim else ""
        p = accessor(gl, binc, prim["attributes"]["POSITION"])
        p = (np.c_[p, np.ones(len(p))] @ m.T)[:, :3]
        n = len(p)
        attrs = {}
        for a in FACE_ATTRS + CORNER_ATTRS:
            k = prim["attributes"].get(a)
            attrs[a] = accessor(gl, binc, k)[:, 0].round().astype(np.int64) if k is not None else np.zeros(n, np.int64)
            attr_all[a].append(attrs[a])
        k = prim["attributes"].get("TEXCOORD_0")
        if k is not None:
            has_uv = True
            uv_all.append(accessor(gl, binc, k)[:, :2])
        else:
            uv_all.append(np.zeros((n, 2)))
        pos_all.append(p)
        idx = accessor(gl, binc, prim["indices"])[:, 0].astype(np.int64).reshape(-1, 3)
        groups = {}
        order = []
        for t in idx:
            sec, fid = attrs["_GT2_SEC"][t[0]], attrs["_GT2_FACE"][t[0]]
            if fid <= 0 or sec <= 0:
                faces.append((mat, [int(base + q) for q in t]))
                continue
            key = (int(sec), int(fid))
            g = groups.get(key)
            if g is None:
                g = groups[key] = {}
                order.append(key)
            for q in t:
                g.setdefault(int(attrs["_GT2_CORNER"][q]), []).append(int(base + q))
        for key in order:
            g = groups[key]
            ok = all(len({tuple(np.round(pos_all[-1][v - base], 6)) for v in vs}) == 1 for vs in g.values())
            if ok and len(g) >= 3:
                faces.append((mat, [g[c][0] for c in sorted(g)]))
            else:
                # Two faces with one id (an editor copy) or a face missing corners: keep its triangles as
                # separate faces (the compiler sorts out which one keeps the id).
                tri = [t for t in idx if (attrs["_GT2_SEC"][t[0]], attrs["_GT2_FACE"][t[0]]) == key]
                for t in tri:
                    faces.append((mat, [int(base + q) for q in t]))
        base += n
    if not pos_all:
        return np.zeros((0, 3)), {a: np.zeros(0, np.int64) for a in attr_all}, None, []
    uvs = np.vstack(uv_all) if has_uv else None
    return np.vstack(pos_all), {a: np.concatenate(v) for a, v in attr_all.items()}, uvs, faces


def _set_image_linked(img):
    """A texture page stays a link to its file: never packed, never saved into the .blend."""
    img[PAGE_IMAGE] = True
    # Kept in the .blend as a link even when no face uses the page yet (the picker shows every texture).
    img.use_fake_user = True
    if img.packed_file is not None:
        try:
            img.unpack(method='USE_ORIGINAL' if os.path.isfile(bpy.path.abspath(img.filepath)) else 'WRITE_ORIGINAL')
        except RuntimeError:
            pass
    # Relative to the .blend when the file is saved, so the folder can be moved with its textures.
    if bpy.data.filepath:
        try:
            img.filepath = bpy.path.relpath(bpy.path.abspath(img.filepath))
        except ValueError:      # another drive on Windows
            pass


def page_image(pages_dir, page, load=True):
    """The texture page `page` (file name) of `pages_dir`, loaded once and linked (not packed). load=False only
    finds one already loaded (panel drawing may not add images)."""
    path = os.path.join(bpy.path.abspath(pages_dir), page)
    for img in bpy.data.images:
        if img.get(PAGE_IMAGE) and os.path.normcase(os.path.abspath(bpy.path.abspath(img.filepath))) == \
                os.path.normcase(os.path.abspath(path)):
            return img
    if not load or not os.path.isfile(path):
        return None
    img = bpy.data.images.load(path, check_existing=True)
    img.name = page
    _set_image_linked(img)
    return img


GROUP = "GT2 texel"


def _texel_group():
    """One shared shader group (page color -> base color, alpha through a 0.5 cut-off: GT2's clear texels). Each
    tex: material is only page -> group -> output, which keeps a course's 1,600-odd materials small in the .blend."""
    ng = bpy.data.node_groups.get(GROUP)
    if ng is not None:
        return ng
    ng = bpy.data.node_groups.new(GROUP, "ShaderNodeTree")
    ng.interface.new_socket("Color", in_out='INPUT', socket_type='NodeSocketColor')
    ng.interface.new_socket("Alpha", in_out='INPUT', socket_type='NodeSocketFloat')
    ng.interface.new_socket("Shader", in_out='OUTPUT', socket_type='NodeSocketShader')
    gi = ng.nodes.new("NodeGroupInput")
    go = ng.nodes.new("NodeGroupOutput")
    bsdf = ng.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 1.0
    cut = ng.nodes.new("ShaderNodeMath")
    cut.operation = 'GREATER_THAN'
    cut.inputs[1].default_value = 0.5
    gi.location, cut.location, bsdf.location, go.location = (-400, 0), (-200, -200), (0, 0), (300, 0)
    ng.links.new(gi.outputs["Color"], bsdf.inputs["Base Color"])
    ng.links.new(gi.outputs["Alpha"], cut.inputs[0])
    ng.links.new(cut.outputs[0], bsdf.inputs["Alpha"])
    ng.links.new(bsdf.outputs[0], go.inputs["Shader"])
    return ng


def _textured_material(m, img, tex):
    """Nodes: the page (closest texel, clamped) -> the shared GT2 texel group -> output. Solid view with Color:
    Texture shows the active image node."""
    if m.node_tree is None:
        m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (300, 0)
    grp = nt.nodes.new("ShaderNodeGroup")
    grp.node_tree = _texel_group()
    grp.location = (0, 0)
    it = nt.nodes.new("ShaderNodeTexImage")
    it.location = (-300, 0)
    it.image = img
    it.interpolation = 'Closest'
    it.extension = 'EXTEND'
    nt.links.new(it.outputs["Color"], grp.inputs["Color"])
    nt.links.new(it.outputs["Alpha"], grp.inputs["Alpha"])
    nt.links.new(grp.outputs[0], out.inputs[0])
    nt.nodes.active = it
    for attr, val in (("blend_method", 'CLIP'), ("surface_render_method", 'DITHERED')):
        try:
            setattr(m, attr, val)
        except (AttributeError, TypeError):
            pass
    m.use_backface_culling = False
    m.diffuse_color = (1, 1, 1, 1)
    m["gt2_tex_entry"] = int(tex["entry"])
    m["gt2_tex_uv"] = [float(x) for c in tex["uv"] for x in c]
    m["gt2_tex_page"] = tex.get("page", "")


def material_for(name, tex=None, pages_dir=None):
    """The material `name`: a flat color (mesh only), or the entry's texture page when `tex` and its page exist."""
    m = bpy.data.materials.get(name)
    if m is None:
        m = bpy.data.materials.new(name)
        m.diffuse_color = meshonly.name_colour(name)
    if tex is not None and pages_dir and "gt2_tex_uv" not in m:
        img = page_image(pages_dir, tex["page"])
        if img is not None:
            _textured_material(m, img, tex)
    return m


def build_object(name, pos, attrs, faces, uvs=None, texinfo=None, pages_dir=None):
    """A Blender mesh object: course meters (glTF y-up) -> Blender z-up (x, -z, y); equal positions welded,
    except where one face would use a vertex twice (degenerate faces keep their own corners). With `uvs`, a UV
    layer from TEXCOORD_0 (glTF v down -> Blender v up); `texinfo` names each material's texture entry."""
    bpos = np.c_[pos[:, 0], -pos[:, 2], pos[:, 1]].astype(np.float32)
    weld = {}
    verts = []
    loops_v, loops_src, poly_start, poly_total, poly_mat, poly_src = [], [], [], [], [], []
    mats = {}
    seen = set()
    for mat, vs in faces:
        keys = [bpos[v].tobytes() for v in vs]
        # A face over the same corners as an earlier one (the two sides of a double-sided wall) gets vertices of
        # its own: Blender's mesh validation (which the glTF exporter runs) deletes duplicate faces.
        twin = frozenset(keys) in seen
        seen.add(frozenset(keys))
        used = set()
        poly_start.append(len(loops_v))
        poly_total.append(len(vs))
        for v, key in zip(vs, keys):
            bi = None if twin else weld.get(key)
            if bi is None or bi in used:
                bi = len(verts)
                verts.append(bpos[v])
                if key not in weld:
                    weld[key] = bi
            used.add(bi)
            loops_v.append(bi)
            loops_src.append(v)
        poly_mat.append(mats.setdefault(mat, len(mats)))
        poly_src.append(vs[0])
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(verts))
    if verts:
        me.vertices.foreach_set("co", np.array(verts, dtype=np.float32).ravel())
    me.loops.add(len(loops_v))
    me.loops.foreach_set("vertex_index", np.array(loops_v, dtype=np.int32))
    me.polygons.add(len(poly_start))
    me.polygons.foreach_set("loop_start", np.array(poly_start, dtype=np.int32))
    me.polygons.foreach_set("loop_total", np.array(poly_total, dtype=np.int32))
    me.polygons.foreach_set("material_index", np.array(poly_mat, dtype=np.int32))
    me.update(calc_edges=True)
    texinfo = texinfo or {}
    for mat in sorted(mats, key=mats.get):
        nm = mat or "untex"
        me.materials.append(material_for(nm, texinfo.get(nm), pages_dir))
    ps = np.array(poly_src, dtype=np.int64)
    ls = np.array(loops_src, dtype=np.int64)
    for a in FACE_ATTRS:
        at = me.attributes.new(a, 'INT', 'FACE')
        at.data.foreach_set("value", attrs[a][ps].astype(np.int32) if len(ps) else np.zeros(0, np.int32))
    for a in CORNER_ATTRS:
        at = me.attributes.new(a, 'INT', 'CORNER')
        at.data.foreach_set("value", attrs[a][ls].astype(np.int32) if len(ls) else np.zeros(0, np.int32))
    if uvs is not None and len(ls):
        lay = me.uv_layers.new(name=UV_NAME)
        uv = uvs[ls].copy()
        uv[:, 1] = 1.0 - uv[:, 1]
        lay.data.foreach_set("uv", uv.astype(np.float32).ravel())
    ob = bpy.data.objects.new(name, me)
    return ob


def import_edit(path, course=None, collection=None):
    """Read an edit glTF (ours, or one Blender exported from an edit) into a collection; returns it. A textured
    file (course export --edit --textures) brings its texture table and links its pages."""
    gl, binc = read_glb(path)
    ge = gl.get("asset", {}).get("extras", {}).get("gt2_edit", {})
    if course is None:
        course = ge.get("course") or os.path.basename(path).split(".")[0]
    col = collection or bpy.data.collections.new(f"GT2 edit {course}")
    if collection is None:
        bpy.context.scene.collection.children.link(col)
    col[COLLECTION_PROP] = course
    texinfo, pages_dir = {}, None
    table = ge.get("textures")
    if table:
        pages = os.path.join(os.path.dirname(os.path.abspath(path)), "textures")
        if os.path.isdir(pages):
            pages_dir = pages
            if bpy.data.filepath:
                try:
                    pages_dir = bpy.path.relpath(pages)
                except ValueError:
                    pass
            col[TABLE_PROP] = json.dumps(table, separators=(",", ":"))
            col[PAGES_PROP] = pages_dir
            for page in sorted({t["page"] for t in table if "page" in t}):
                page_image(pages_dir, page)
            by_entry = {int(t["entry"]): t for t in table}
            for mt in gl.get("materials", []):
                gt = mt.get("extras", {}).get("gt2_tex")
                nm = mt.get("name", "")
                if gt is not None and nm.startswith("tex:"):
                    t = dict(by_entry.get(int(gt["entry"]), {}))
                    t.setdefault("entry", int(gt["entry"]))
                    t.setdefault("uv", gt["uv"])
                    if "page" in t:
                        texinfo[nm] = t
    for node_name, mi, m in mesh_nodes(gl):
        pos, attrs, uvs, faces = _faces_of(gl, binc, mi, m)
        if not faces:
            continue
        low = "low" in node_name.lower()
        ob = build_object("gt2_track_low" if low else "gt2_track", pos, attrs, faces,
                          uvs if pages_dir else None, texinfo, pages_dir)
        ob["gt2_mesh"] = "low" if low else "high"
        col.objects.link(ob)
        if low:
            ob.hide_set(True)
    return col


def edit_objects(col):
    return [o for o in col.all_objects if o.type == 'MESH' and o.get("gt2_mesh") in ("high", "low")]


def export_edit(col, path):
    """Blender's glTF exporter on the collection's two meshes, with the _GT2_* attributes; materials by name only
    (no images: a textured edit's pages never go into the .glb) and no normals or UVs (the compiler takes
    neither)."""
    obs = edit_objects(col)
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    hidden = []
    for o in obs:
        if o.hide_get():
            hidden.append(o)
            o.hide_set(False)
        o.select_set(True)
    try:
        bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_yup=True,
                                  export_apply=False, export_attributes=True, export_normals=False,
                                  export_texcoords=False, export_tangents=False, export_materials='EXPORT',
                                  export_image_format='NONE',
                                  export_vertex_color='NONE', export_animations=False, export_skins=False,
                                  export_morph=False, export_cameras=False, export_lights=False,
                                  export_extras=False)
    finally:
        for o in hidden:
            o.hide_set(True)
    return path


# ---------------------------------------------------------------------------------------------------------------
# Texture table and the per-face picker


_tables = {}        # collection name -> (json text, list of entries)


def texture_table(col):
    """The course's texture table kept on the edit collection: [{entry, page, uv: 4 x [u, v]}], or []."""
    if col is None or TABLE_PROP not in col:
        return []
    raw = col[TABLE_PROP]
    hit = _tables.get(col.name)
    if hit is None or hit[0] != raw:
        hit = (raw, json.loads(raw))
        _tables[col.name] = hit
    return hit[1]


def entry_of(col, entry):
    for t in texture_table(col):
        if int(t["entry"]) == entry:
            return t
    return None


def corner_uvs(tex, corners):
    """Blender UVs (v up) for a face's corners: GT2 corner c takes the entry's UV c."""
    uv = tex["uv"]
    return [(float(uv[c % len(uv)][0]), 1.0 - float(uv[c % len(uv)][1])) for c in corners]


def assign_texture(ob, col, entry, faces=None):
    """Move faces of `ob` (indices; None = the selected ones) to material tex:ENTRY and rewrite their UVs from
    the entry's corner UVs (GT2 corner from _GT2_CORNER on a GT2 face, the corner's place on a new face).
    Works in edit mode and object mode. Returns the number of faces changed."""
    tex = entry_of(col, entry)
    if tex is None:
        raise ValueError(f"tex:{entry:04d} is not in this course's texture table")
    name = f"tex:{entry:04d}"
    mat = material_for(name, tex, col.get(PAGES_PROP))
    me = ob.data
    slot = next((i for i, m in enumerate(me.materials) if m is not None and m.name == name), None)
    if slot is None:
        me.materials.append(mat)
        slot = len(me.materials) - 1
    if ob.mode == 'EDIT':
        import bmesh
        bm = bmesh.from_edit_mesh(me)
        cl = bm.loops.layers.int.get("_GT2_CORNER")
        fl = bm.faces.layers.int.get("_GT2_FACE")
        uvl = bm.loops.layers.uv.get(UV_NAME) or bm.loops.layers.uv.active
        n = 0
        bm.faces.ensure_lookup_table()
        sel = [bm.faces[i] for i in faces] if faces is not None else [f for f in bm.faces if f.select]
        for f in sel:
            f.material_index = slot
            if uvl is not None:
                gt2 = fl is not None and f[fl] > 0
                cs = [l[cl] if (gt2 and cl is not None) else k for k, l in enumerate(f.loops)]
                for l, uv in zip(f.loops, corner_uvs(tex, cs)):
                    l[uvl].uv = uv
            n += 1
        bmesh.update_edit_mesh(me)
        return n
    sel = faces if faces is not None else [p.index for p in me.polygons if p.select]
    ca = me.attributes.get("_GT2_CORNER")
    fa = me.attributes.get("_GT2_FACE")
    uvl = me.uv_layers.get(UV_NAME) or me.uv_layers.active
    for i in sel:
        p = me.polygons[i]
        p.material_index = slot
        if uvl is not None:
            gt2 = fa is not None and fa.data[i].value > 0
            cs = [ca.data[li].value if (gt2 and ca is not None) else k for k, li in enumerate(p.loop_indices)]
            for li, uv in zip(p.loop_indices, corner_uvs(tex, cs)):
                uvl.data[li].uv = uv
    me.update()
    return len(sel)


# Picker icons: a crop of each entry from its page, made on this machine from the linked pages (never saved).
_previews = {"coll": None, "key": None, "items": [], "made": 0}


def _crop_icon(pcoll, key, img, uv, size=32):
    w, h = img.size
    if w == 0 or h == 0:
        return 0
    us = [c[0] for c in uv]
    vs = [c[1] for c in uv]
    x0, x1 = int(min(us) * w), max(int(np.ceil(max(us) * w)), int(min(us) * w) + 1)
    y0, y1 = int(min(vs) * h), max(int(np.ceil(max(vs) * h)), int(min(vs) * h) + 1)
    px = _pixels(img)
    # glTF v runs down the page; Blender's pixel rows run up.
    crop = px[h - y1:h - y0, x0:x1]
    if crop.size == 0:
        return 0
    yi = (np.arange(size) * crop.shape[0] // size).clip(0, crop.shape[0] - 1)
    xi = (np.arange(size) * crop.shape[1] // size).clip(0, crop.shape[1] - 1)
    icon = crop[yi][:, xi]
    pv = pcoll.new(key)
    pv.icon_size = (size, size)
    pv.image_size = (size, size)
    pv.image_pixels_float = icon.astype(np.float32).ravel()
    _previews["made"] += 1
    return pv.icon_id


_pix = {}


def _pixels(img):
    hit = _pix.get(img.name)
    if hit is None:
        w, h = img.size
        a = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(a)
        hit = _pix[img.name] = a.reshape(h, w, 4)
    return hit


_NO_TABLE = [("-1", "No texture table (Edit with Show textures)", "")]


def picker_items(self, context):
    """Every texture of the edited course, as (entry, tex:NNNN, page) with a crop of the page as its icon."""
    col = edit_collection(context)
    table = texture_table(col)
    if not table:
        return _NO_TABLE
    key = (col.name, len(table))
    if _previews["key"] == key:
        return _previews["items"]
    if _previews["coll"] is not None:
        bpy.utils.previews.remove(_previews["coll"])
    pcoll = bpy.utils.previews.new()
    _previews["made"] = 0
    _pix.clear()
    items = []
    pages = col.get(PAGES_PROP)
    for t in table:
        e = int(t["entry"])
        icon = 0
        img = page_image(pages, t["page"], load=False) if pages else None
        if img is not None:
            try:
                icon = _crop_icon(pcoll, f"e{e}", img, t["uv"])
            except Exception:
                icon = 0
        items.append((str(e), f"tex:{e:04d}", f"{t['page']}", icon, e))
    _pix.clear()
    _previews.update(coll=pcoll, key=key, items=items)
    return items


def packed_pages():
    return [i for i in bpy.data.images if i.get(PAGE_IMAGE) and i.packed_file is not None]


def edit_collection(context):
    for c in bpy.data.collections:
        if COLLECTION_PROP in c and edit_objects(c):
            if context.collection is c or any(o in c.all_objects.values() for o in context.selected_objects):
                return c
    for c in bpy.data.collections:
        if COLLECTION_PROP in c and edit_objects(c):
            return c
    return None


# ---------------------------------------------------------------------------------------------------------------
# Operators (the add-on's GT2 tab)


def _pkg():
    from . import (check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir)
    return check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir


class GT2TRACK_OT_edit_course(bpy.types.Operator):
    """Open a GT2 course from your own data for editing: faces keep their ids and texture names. With Show textures, the course's texture pages are linked from files beside the .blend (never packed into it)"""
    bl_idname = "gt2track.edit_course"
    bl_label = "Edit GT2 course"

    course: bpy.props.StringProperty(name="Course", default="laguna")
    textures: bpy.props.BoolProperty(name="Show textures", default=False)

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        port = port_dir()
        course = self.course.strip()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        # Linked textures need a saved .blend: the pages sit next to it and the links are relative.
        work = work_dir("gt2-edit", need_saved=self.textures)
        if work is None:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the texture pages are written next to it")
            return {'CANCELLED'}
        if self.textures:
            work = os.path.join(work, course)
            os.makedirs(work, exist_ok=True)
        args = ["course", "export", course, "--edit"] + (["--textures"] if self.textures else []) + \
            ["--data", data_path(port), "--out", work]
        code, log = gt2_tools(*args)
        glb = os.path.join(work, course + ".edit.glb")
        if code != 0 or not os.path.isfile(glb):
            self.report({'ERROR'}, f"gt2-tools could not export {course}: {last_problem(log)}")
            return {'CANCELLED'}
        col = import_edit(glb, course)
        if self.textures and not bpy.app.background:
            for area in context.screen.areas if context.screen else []:
                if area.type == 'VIEW_3D':
                    for sp in area.spaces:
                        if sp.type == 'VIEW_3D' and sp.shading.type == 'SOLID':
                            sp.shading.color_type = 'TEXTURE'
        # The export is game-derived: it stays on this machine, next to the .blend (or in temp).
        n = sum(len(o.data.polygons) for o in edit_objects(col))
        extra = ", textures linked from gt2-edit/" + course + "/textures" if self.textures else ""
        self.report({'INFO'}, f"{course}: {n} faces to edit (gt2_track; the mirror's gt2_track_low is hidden){extra}")
        return {'FINISHED'}


class GT2TRACK_OT_build_edited(bpy.types.Operator):
    """Compile the edited course against the original from your data (gt2-tools edit) and install it as a mod"""
    bl_idname = "gt2track.build_edited_course"
    bl_label = "Build edited course"

    as_new: bpy.props.StringProperty(name="As new course", default="",
                                     description="Empty: replace the course. A name: add it as a new course")

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        port = port_dir()
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the build files are written next to it")
            return {'CANCELLED'}
        col = edit_collection(context)
        if col is None:
            self.report({'ERROR'}, "No GT2 course to build: use Edit GT2 course first")
            return {'CANCELLED'}
        course = col[COLLECTION_PROP]
        cd = bpy.path.abspath("//")
        glb = export_edit(col, os.path.join(cd, f"{course}.edited.glb"))
        out = os.path.join(cd, "out", f"{course}-edit")
        modname = f"Edit_{course}"
        args = ["edit", course, glb, "--out", out, "--data", data_path(port), "--mod", modname,
                "--patch-out", os.path.join(cd, f"{course}.gt2patch")]
        if self.as_new.strip():
            args += ["--add", self.as_new.strip()]
        code, log = gt2_tools(*args)
        with open(os.path.join(cd, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: build-log.txt)")
            return {'CANCELLED'}
        src = os.path.join(out, "mods", modname)
        lines = [l for l in log.splitlines() if l.strip()]
        changed = next((l.split(": ", 1)[-1] for l in lines if "sections changed" in l), "built")
        warn = " Textures are PACKED in this .blend: unpack them before you save." if packed_pages() else ""
        if os.path.isdir(src) and os.listdir(src):
            install_mod(src, mods_path(port), modname)
            msg = (f"Built {course}: {changed} (mod {modname}, on in mods/load-order.txt; share {course}.gt2patch, "
                   "never the .blend or the textures).")
        else:
            # Unchanged: the compiler writes no mod; an older build of this mod would play stale edits.
            shutil.rmtree(os.path.join(mods_path(port), modname), ignore_errors=True)
            msg = f"{course} is unchanged: nothing to install (an older {modname} mod was removed)."
        self.report({'WARNING' if warn else 'INFO'}, msg + warn)
        return {'FINISHED'}


class GT2TRACK_OT_apply_texture(bpy.types.Operator):
    """Give the selected faces the picked texture (its material tex:NNNN and its UVs)"""
    bl_idname = "gt2track.apply_texture"
    bl_label = "Apply to selected faces"
    bl_options = {'REGISTER', 'UNDO'}

    entry: bpy.props.IntProperty(name="Entry", default=-1)

    def execute(self, context):
        col = edit_collection(context)
        entry = self.entry if self.entry >= 0 else int(context.window_manager.gt2_tex_pick or -1)
        ob = context.object
        if col is None or ob is None or ob not in edit_objects(col):
            self.report({'ERROR'}, "Select faces of gt2_track (or gt2_track_low) first")
            return {'CANCELLED'}
        if entry < 0:
            self.report({'ERROR'}, "Pick a texture first")
            return {'CANCELLED'}
        try:
            n = assign_texture(ob, col, entry)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        if n == 0:
            self.report({'WARNING'}, "No faces selected (Tab into Edit Mode, face select, pick faces)")
            return {'CANCELLED'}
        self.report({'INFO'}, f"{n} faces now use tex:{entry:04d}")
        return {'FINISHED'}


class GT2TRACK_OT_pick_from_face(bpy.types.Operator):
    """Pick the texture of the active face"""
    bl_idname = "gt2track.pick_from_face"
    bl_label = "From active face"

    def execute(self, context):
        ob = context.object
        if ob is None or ob.type != 'MESH':
            return {'CANCELLED'}
        me = ob.data
        if ob.mode == 'EDIT':
            import bmesh
            f = bmesh.from_edit_mesh(me).faces.active
            idx = f.material_index if f is not None else None
        else:
            idx = me.polygons[me.polygons.active].material_index if me.polygons else None
        m = me.materials[idx] if idx is not None and idx < len(me.materials) else None
        if m is None or not m.name.startswith("tex:"):
            self.report({'WARNING'}, "The active face has no tex: material")
            return {'CANCELLED'}
        try:
            context.window_manager.gt2_tex_pick = str(int(m.name[4:8]))
        except (TypeError, ValueError):
            self.report({'WARNING'}, f"{m.name} is not in this course's texture table")
            return {'CANCELLED'}
        return {'FINISHED'}


class GT2TRACK_OT_find_texture(bpy.types.Operator):
    """Find a texture of the course by its number"""
    bl_idname = "gt2track.find_texture"
    bl_label = "Find texture"
    bl_property = "pick"

    pick: bpy.props.EnumProperty(items=picker_items)

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        context.window_manager.gt2_tex_pick = self.pick
        return {'FINISHED'}


class GT2TRACK_OT_unpack_pages(bpy.types.Operator):
    """Take the texture pages out of the .blend again: they stay linked to the files in the textures folder"""
    bl_idname = "gt2track.unpack_pages"
    bl_label = "Unpack the textures"

    def execute(self, context):
        imgs = packed_pages()
        for img in imgs:
            _set_image_linked(img)
        bpy.data.use_autopack = False
        self.report({'INFO'}, f"{len(imgs)} texture pages linked again (not in the .blend)")
        return {'FINISHED'}


@bpy.app.handlers.persistent
def _save_pre(*_args):
    """The pages must never be saved inside a .blend: a packed page is unpacked (linked to its file) before saving."""
    imgs = packed_pages()
    if imgs:
        print(f"GT2 Tools: {len(imgs)} GT2 texture pages were packed into this .blend; linking them to their files "
              "again (they are game pixels: share the .gt2patch, not the .blend)")
        for img in imgs:
            _set_image_linked(img)


class GT2TRACK_PT_course_edit(bpy.types.Panel):
    bl_label = "Edit a GT2 course"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        wm = context.window_manager
        row = lay.row(align=True)
        row.prop(wm, "gt2_course", text="")
        op = row.operator("gt2track.edit_course", text="Edit", icon='EDITMODE_HLT')
        op.course = wm.gt2_course
        op.textures = wm.gt2_edit_textures
        lay.prop(wm, "gt2_edit_textures")
        lay.operator("gt2track.build_edited_course", icon='AUTO')
        packed = packed_pages()
        if packed or (bpy.data.use_autopack and any(i.get(PAGE_IMAGE) for i in bpy.data.images)):
            box = lay.box()
            box.alert = True
            box.label(text="GT2 textures are packed into this .blend!", icon='ERROR')
            box.label(text="They are game pixels: keep them linked.")
            box.operator("gt2track.unpack_pages", icon='UGLYPACKAGE')
        col = edit_collection(context)
        if col is not None and texture_table(col):
            box = lay.box()
            box.label(text="Texture of the selected faces:")
            box.template_icon_view(wm, "gt2_tex_pick", show_labels=True, scale=5.0, scale_popup=3.0)
            row = box.row(align=True)
            row.operator("gt2track.find_texture", text="Find", icon='VIEWZOOM')
            row.operator("gt2track.pick_from_face", text="From face", icon='EYEDROPPER')
            box.operator("gt2track.apply_texture", icon='TEXTURE')
        box = lay.box()
        box.label(text="Materials are tex:NNNN names (or untex).")
        box.label(text="New faces: give them a tex: material.")
        box.label(text="Share the .gt2patch, not the .blend", icon='INFO')
        box.label(text="or the textures folder (game pixels).")


classes = (GT2TRACK_OT_edit_course, GT2TRACK_OT_build_edited, GT2TRACK_OT_apply_texture, GT2TRACK_OT_pick_from_face,
           GT2TRACK_OT_find_texture, GT2TRACK_OT_unpack_pages, GT2TRACK_PT_course_edit)


def register():
    bpy.types.WindowManager.gt2_edit_textures = bpy.props.BoolProperty(
        name="Show textures", default=True,
        description="Show the course's textures (linked from texture pages made from your install, next to the "
                    ".blend; never packed into it)")
    bpy.types.WindowManager.gt2_tex_pick = bpy.props.EnumProperty(name="Texture", items=picker_items)
    for c in classes:
        bpy.utils.register_class(c)
    if _save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(_save_pre)


def unregister():
    if _save_pre in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(_save_pre)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    if _previews["coll"] is not None:
        bpy.utils.previews.remove(_previews["coll"])
        _previews.update(coll=None, key=None, items=[])
    del bpy.types.WindowManager.gt2_tex_pick
    del bpy.types.WindowManager.gt2_edit_textures
