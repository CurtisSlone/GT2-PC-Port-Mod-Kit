# GT2 Tools: the "GT2" tab in the 3D view's sidebar (press N with the mouse over the 3D view).
#
# This add-on is the only Python the release ships. It holds no GT2 data: everything GT2-derived (the starter
# scene with Laguna Seca, courses and cars opened for editing, texture pages) is generated on the player's machine
# from the data their own disc installed into the port folder, by the mod kit's one program, gt2-tools
# (docs/crates/gt2-tools.md).
#
# * GT2 Track panel: Create starter project (`gt2-tools course export laguna2`, then a background Blender builds
#   the starter scene, starter.py), Build track for GT2 (`gt2-tools track new` into the mod MyTrack), place
#   markers, a GT2 course added for reference.
# * Edit a GT2 course panel (course_edit.py): `course export --edit [--textures]`, a per-face texture picker,
#   `gt2-tools edit` back into a mod.
# * GT2 Car panel (car_edit.py): `car export --edit`, `car import --glb` into a mod, `car preview`.
#
# Finding gt2-tools: the preference "gt2-tools program", else <port folder>/gt2-tools(.exe), else beside the
# add-on's own files (up to three folders above them: an add-on loaded straight from the kit folder), else PATH.
# The port folder (data and mods): the preference, else the folder gt2-tools sits in when it has a data folder.
#
# Test overrides (environment, they win over the preferences): GT2_TOOLS (the gt2-tools program), GT2_RUNTIME (the
# port folder), GT2_DATA (the data: a gt2vol folder, the port's data folder or the port folder).

import json
import os
import shutil
import subprocess
import tempfile

import bpy

from . import car_edit
from . import course_edit
from . import meshonly

# Legacy add-on metadata (Blender before 4.2, or "Install from Disk" of the zip as an old-style add-on).
# Blender 4.2+ extensions read blender_manifest.toml instead.
bl_info = {
    "name": "GT2 Tools",
    "author": "PSX Runtime project",
    "version": (0, 4, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar (N) > GT2",
    "description": "Make GT2 tracks, edit GT2 courses (with their textures) and cars from your own GT2 data",
    "category": "Import-Export",
}

HERE = os.path.dirname(os.path.abspath(__file__))
MOD = "MyTrack"
COURSE = "zz_mytrack"
# Mods that carry their own course list (.crsinfo): only one of them works at a time.
COURSE_MODS = ["SampleTrack", "X3Course", "TrackOval", "TrackBankedOval", "TrackFigure8", "TrackRoadCourse",
               "MySketch", MOD]
TOOL = "gt2-tools"


# ---------------------------------------------------------------------------------------------------------------
# gt2-tools and the port folder


def prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except (KeyError, AttributeError):
        return None


def blend_dir():
    return bpy.path.abspath("//")


def _exe_in(folder):
    """gt2-tools(.exe) in a folder, or None."""
    if not folder:
        return None
    for n in (TOOL + ".exe", TOOL):
        p = os.path.join(folder, n)
        if os.path.isfile(p):
            return p
    return None


def _pref(name):
    p = prefs()
    v = getattr(p, name, "") if p is not None else ""
    return bpy.path.abspath(v.strip()) if v and v.strip() else ""


def find_tools():
    """The gt2-tools program: (path or None, where it was found)."""
    env = os.environ.get("GT2_TOOLS")
    if env:
        return env, "GT2_TOOLS"
    p = _pref("tools_path")
    if p:
        if os.path.isdir(p):
            p = _exe_in(p) or p
        return p, "preference"
    port = os.environ.get("GT2_RUNTIME", "") or _pref("port_folder")
    hit = _exe_in(port)
    if hit:
        return hit, "port folder"
    d = HERE
    for _ in range(4):
        d = os.path.dirname(d)
        hit = _exe_in(d)
        if hit:
            return hit, "beside the add-on"
    hit = shutil.which(TOOL)
    if hit:
        return hit, "PATH"
    return None, ""


def port_dir():
    """The port folder (data and mods): GT2_RUNTIME, the preference, the folder gt2-tools sits in (when it has a
    data folder), else the folder above the .blend's folder (the old starter lived in <port>/custom)."""
    env = os.environ.get("GT2_RUNTIME")
    if env:
        return env
    p = _pref("port_folder")
    if p:
        return p
    exe, _ = find_tools()
    if exe and os.path.isdir(os.path.join(os.path.dirname(exe), "data")):
        return os.path.dirname(exe)
    if bpy.data.filepath:
        return os.path.dirname(os.path.normpath(blend_dir()))
    return ""


def data_path(port):
    """What --data gets: the port folder (gt2-tools finds data/gt2vol inside), or the GT2_DATA override."""
    return os.environ.get("GT2_DATA") or port


def mods_path(port):
    return os.path.join(port, "mods")


def _has_data(port):
    d = os.environ.get("GT2_DATA")
    if d:
        return os.path.isdir(d)
    return os.path.isdir(os.path.join(port, "data", "gt2vol"))


def check_port(port=None):
    """Problems with the setup as short sentences; empty when it is usable."""
    out = []
    exe, _ = find_tools()
    if not exe or not os.path.isfile(exe):
        out.append("gt2-tools not found: set it in Preferences > Add-ons > GT2 Tools")
    port = port_dir() if port is None else port
    if not port:
        out.append("Set the port folder: Preferences > Add-ons > GT2 Tools")
    elif not os.path.isdir(port):
        out.append(f"Port folder not found: {port}")
    elif not _has_data(port):
        out.append("data/gt2vol is missing: install GT2 from your disc first")
    return out


def tools_cmd():
    exe, _ = find_tools()
    return [exe]


def run(cmd, timeout=900):
    """Run a tool without a console window popping up on Windows; returns (exit code, all output)."""
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)
    except (OSError, subprocess.SubprocessError) as e:
        return 127, f"could not run {cmd[0]}: {e}"
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def gt2_tools(*args, timeout=900):
    """gt2-tools ARGS...; returns (exit code, all output)."""
    return run(tools_cmd() + [str(a) for a in args], timeout=timeout)


def last_problem(log):
    lines = [l for l in log.splitlines() if l.strip()]
    problems = [l for l in lines if "error" in l.lower() or "warning" in l.lower()]
    return problems[-1] if problems else (lines[-1] if lines else "unknown error")


def export_course(port, course, out):
    """gt2-tools course export COURSE into OUT; returns (glTF path or None, log)."""
    code, log = gt2_tools("course", "export", course, "--data", data_path(port), "--out", out)
    gltf = os.path.join(out, "view", course + ".gltf")
    if code != 0 or not os.path.isfile(gltf):
        return None, log
    return gltf, log


def install_mod(src, mods, name):
    """Copy a built mod folder into the port's mods folder (replacing the old copy) and turn it on."""
    dst = os.path.join(mods, name)
    os.makedirs(mods, exist_ok=True)
    shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(src, dst)
    enable_mod(mods, name)
    return dst


def enable_mod(mods_dir, name):
    """Turn the mod on in load-order.txt (with that file, only the folders it lists load): its line is added at
    the end, or its # removed. Other lines stay as they are. Without the file every folder loads."""
    path = os.path.join(mods_dir, "load-order.txt")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        lines = [l.rstrip("\r\n") for l in f]
    out, seen = [], False
    for l in lines:
        if l.lstrip("#").strip() == name:
            if not seen:
                out.append(name)
            seen = True
        else:
            out.append(l)
    if not seen:
        out.append(name)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(out) + "\n")


def work_dir(sub, need_saved=False):
    """A work folder next to the .blend (or in Blender's temp folder for an unsaved file)."""
    if bpy.data.filepath:
        base = blend_dir()
    elif need_saved:
        return None
    else:
        base = bpy.app.tempdir or tempfile.gettempdir()
    d = os.path.join(base, sub)
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------------------------------------------
# Track helpers


def track_length(obj):
    if obj is None or obj.type != 'MESH':
        return 0.0
    m = obj.matrix_world
    vs = [m @ v.co for v in obj.data.vertices]
    return sum((vs[e.vertices[0]] - vs[e.vertices[1]]).length for e in obj.data.edges)


def set_load_order(mods_dir):
    path = os.path.join(mods_dir, "load-order.txt")
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lines = [l.rstrip("\r\n") for l in f]
    out, seen = [], False
    for l in lines:
        name = l.lstrip("#").strip()
        if name == MOD:
            out.append(MOD)
            seen = True
        elif name in COURSE_MODS and not l.startswith("#"):
            out.append("#" + name)
        else:
            out.append(l)
    if not seen:
        out.append(MOD)
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(out) + "\n")


# ---------------------------------------------------------------------------------------------------------------
# Preferences


class GT2TRACK_AP_prefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    port_folder: bpy.props.StringProperty(
        name="Port folder", subtype='DIR_PATH',
        description="The GT2 port folder: the one with UGT2R, gt2-tools, data and mods. Empty: the folder "
                    "gt2-tools is in")
    tools_path: bpy.props.StringProperty(
        name="gt2-tools program", subtype='FILE_PATH',
        description="Only if gt2-tools is not in the port folder or on PATH: gt2-tools.exe (Windows) or gt2-tools "
                    "(Linux)")

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "port_folder")
        lay.prop(self, "tools_path")
        exe, where = find_tools()
        if exe and os.path.isfile(exe):
            lay.label(text=f"gt2-tools: {exe} ({where})", icon='CHECKMARK')
        problems = check_port()
        if problems:
            for p in problems:
                lay.label(text=p, icon='ERROR')
        else:
            lay.label(text="Port folder OK: gt2-tools and your GT2 data found", icon='CHECKMARK')


# ---------------------------------------------------------------------------------------------------------------
# Operators


class GT2TRACK_OT_create_starter(bpy.types.Operator):
    """Make a starter .blend from your own GT2 data: grid, Laguna Seca at true size, size references and a sample road"""
    bl_idname = "gt2track.create_starter"
    bl_label = "Create starter project"

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.blend", options={'HIDDEN'})
    open_after: bpy.props.BoolProperty(name="Open it when done", default=True)

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = "GT2_Track_Starter.blend"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        out = bpy.path.abspath(self.filepath)
        if not out.lower().endswith(".blend"):
            out += ".blend"
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        port = port_dir()
        tmp = tempfile.mkdtemp(prefix="gt2-starter-")
        try:
            gltf, log = export_course(port, "laguna2", os.path.join(tmp, "laguna"))
            if gltf is None:
                self.report({'ERROR'}, f"gt2-tools could not export Laguna Seca: {last_problem(log)}")
                return {'CANCELLED'}
            # A second Blender builds and saves the scene, so the open file and its undo history stay as they are.
            cmd = [bpy.app.binary_path, "-b", "--factory-startup", "--python-exit-code", "1",
                   "--python", os.path.join(HERE, "starter.py"), "--",
                   gltf, os.path.join(HERE, "sample_track.csv"), os.path.join(HERE, "QUICKSTART.txt"), out]
            code, log = run(cmd)
            if code != 0 or not os.path.isfile(out):
                logf = os.path.splitext(out)[0] + "-log.txt"
                with open(logf, "w", encoding="utf-8") as f:
                    f.write(log)
                self.report({'ERROR'}, f"Building the starter failed: {last_problem(log)}  (all of it: {logf})")
                return {'CANCELLED'}
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        if self.open_after and not bpy.app.background:
            if bpy.data.is_dirty:
                self.report({'WARNING'}, f"Saved {out}. Your open file has unsaved changes: open the starter "
                                         "with File > Open when ready")
                return {'FINISHED'}
            bpy.ops.wm.open_mainfile(filepath=out)
        self.report({'INFO'}, f"Starter project saved: {out}")
        return {'FINISHED'}


class GT2TRACK_OT_build(bpy.types.Operator):
    """Export the Track, compile it for GT2 (gt2-tools track new) and install it as the MyTrack mod"""
    bl_idname = "gt2track.build_track"
    bl_label = "Build track for GT2"

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the track files are written next to it")
            return {'CANCELLED'}
        track = bpy.data.objects.get("Track")
        if track is None or track.type != 'MESH':
            self.report({'ERROR'}, "There is no object named Track (a line of points). Rename your road to Track")
            return {'CANCELLED'}
        if len(track.data.polygons) > 0:
            self.report({'ERROR'}, "Track has faces. It must be a line of points only (edges, no faces)")
            return {'CANCELLED'}
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        rt = port_dir()
        cd = blend_dir()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        # Export only the track, the start marker and the place markers.
        for o in context.view_layer.objects:
            o.select_set(o.name == "Track" or o.name == "Start" or o.name.startswith("Place_"))
        glb = os.path.join(cd, "track.glb")
        bpy.ops.export_scene.gltf(filepath=glb, export_format='GLB', use_selection=True, export_yup=True,
                                  export_apply=True, export_attributes=True, use_mesh_edges=True,
                                  use_mesh_vertices=False, export_materials='NONE', export_animations=False)
        name = context.scene.gt2_track_name.strip() or "My Track"
        spec = os.path.join(cd, "track.json")
        js = {}
        if os.path.exists(spec):
            try:
                with open(spec, encoding="utf-8") as f:
                    js = json.load(f)
            except Exception:
                js = {}
        js.setdefault("import", "track.glb")
        js["name"] = name
        js["add"] = COURSE
        ci = js.setdefault("course_info", {})
        ci["display_name"] = name
        ci.setdefault("sky_from", "laguna2")
        with open(spec, "w", encoding="utf-8") as f:
            json.dump(js, f, indent=2)
        out = os.path.join(cd, "out", "mytrack")
        code, log = gt2_tools("track", "new", spec, "--out", out, "--data", data_path(rt), "--mod", MOD,
                              timeout=600)
        with open(os.path.join(cd, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        lines = [l for l in log.splitlines() if l.strip()]
        if code != 0:
            self.report({'ERROR'}, f"The compiler said no: {last_problem(log)}  (all of it: build-log.txt "
                                   "next to this .blend)")
            return {'CANCELLED'}
        mods = mods_path(rt)
        src = os.path.join(out, "mods", MOD)
        dst = os.path.join(mods, MOD)
        os.makedirs(mods, exist_ok=True)
        shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
        set_load_order(mods)
        km = track_length(track) / 1000.0
        summary = next((l for l in reversed(lines) if "errors" in l), "built")
        self.report({'INFO'}, f"Built \"{name}\" ({km:.2f} km): {summary}. Mod {MOD} is on: start UGT2R with "
                              f"--course {COURSE}")
        return {'FINISHED'}


_courses = []


def course_names():
    """The install's course names from `gt2-tools course list` (asked once per session; the list never changes)."""
    if not _courses and not check_port():
        code, log = gt2_tools("course", "list", "--data", data_path(port_dir()), timeout=60)
        for l in log.splitlines():
            parts = l.split()
            if code == 0 and len(parts) == 2 and parts[0].isdigit():
                _courses.append(parts[1])
    return _courses


def course_items(self, context):
    names = course_names() or ["laguna2"]
    return [(n, n, "") for n in names]


class GT2TRACK_OT_import_course(bpy.types.Operator):
    """Export a GT2 course from your data and add it to this file as a reference (true size, mesh only, no textures)"""
    bl_idname = "gt2track.import_course"
    bl_label = "Add GT2 course"

    course: bpy.props.StringProperty(name="Course", default="laguna2")

    def execute(self, context):
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        port = port_dir()
        course = self.course.strip()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        tmp = tempfile.mkdtemp(prefix="gt2-course-")
        try:
            gltf, log = export_course(port, course, os.path.join(tmp, course))
            if gltf is None:
                self.report({'ERROR'}, f"gt2-tools could not export {course}: {last_problem(log)}")
                return {'CANCELLED'}
            objs, imgs, mats = set(bpy.data.objects), set(bpy.data.images), set(bpy.data.materials)
            bpy.ops.import_scene.gltf(filepath=gltf)
            # Mesh only: no game textures in the .blend; materials keep their names (the asset references).
            meshonly.strip_assets(imgs, mats)
            col = bpy.data.collections.new(f"GT2 course {course} (reference, not exported)")
            context.scene.collection.children.link(col)
            col.color_tag = 'COLOR_04'
            for o in bpy.data.objects:
                if o not in objs:
                    for c in list(o.users_collection):
                        c.objects.unlink(o)
                    col.objects.link(o)
                    # Same layers hidden as in the starter: low detail, collision, AI lines.
                    n = o.name.lower()
                    if any(w in n for w in ("track_low", "collision", "ai line", "ai_line")):
                        o.hide_set(True)
                        o.hide_render = True
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        self.report({'INFO'}, f"Added {course} (move it with its top empty; it is never exported with your track)")
        return {'FINISHED'}


class GT2TRACK_OT_add_place(bpy.types.Operator):
    """Add a place marker at the 3D cursor (where you last clicked)"""
    bl_idname = "gt2track.add_place"
    bl_label = "Add place marker"
    kind: bpy.props.EnumProperty(items=[("Home", "Home", ""), ("Dealer", "Dealer", ""), ("Race", "Race", ""),
                                        ("License", "License", ""), ("Place", "Other", "")])

    def execute(self, context):
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.empty_add(type='SINGLE_ARROW', location=context.scene.cursor.location)
        o = context.object
        o.name = f"Place_{self.kind}"
        o.empty_display_size = 25
        col = bpy.data.collections.get("YOUR TRACK")
        if col and o.name not in col.objects:
            for c in o.users_collection:
                c.objects.unlink(o)
            col.objects.link(o)
        return {'FINISHED'}


# ---------------------------------------------------------------------------------------------------------------
# Panel


def draw_problems(lay):
    problems = check_port()
    if problems:
        box = lay.box()
        for p in problems:
            box.label(text=p, icon='ERROR')
    return problems


class GT2TRACK_PT_panel(bpy.types.Panel):
    bl_label = "GT2 Track"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"

    def draw(self, context):
        lay = self.layout
        draw_problems(lay)
        lay.operator("gt2track.create_starter", icon='FILE_NEW')
        lay.separator()
        track = bpy.data.objects.get("Track")
        lay.prop(context.scene, "gt2_track_name", text="Name")
        if track is not None and track.type == 'MESH':
            lay.label(text=f"Track length: {track_length(track) / 1000.0:.2f} km, {len(track.data.vertices)} points")
        else:
            lay.label(text="No object named Track", icon='ERROR')
        lay.operator("gt2track.build_track", icon='AUTO')
        lay.separator()
        lay.label(text="Place markers (at the 3D cursor):")
        row = lay.row(align=True)
        for k in ("Home", "Dealer", "Race", "License"):
            row.operator("gt2track.add_place", text=k).kind = k
        lay.separator()
        lay.label(text="GT2 course for reference:")
        row = lay.row(align=True)
        row.prop(context.window_manager, "gt2_course", text="")
        row.operator("gt2track.import_course", text="Add", icon='IMPORT').course = context.window_manager.gt2_course
        lay.separator()
        box = lay.box()
        box.label(text="1 grid square = 1 m. Car = 4.5 m long.")
        box.label(text="Roads: 10-20 m wide. Laguna Seca = 3.6 km.")
        box.label(text="Edit the road: select Track, Tab, move points (G).")


classes = (GT2TRACK_AP_prefs, GT2TRACK_OT_create_starter, GT2TRACK_OT_build, GT2TRACK_OT_import_course,
           GT2TRACK_OT_add_place, GT2TRACK_PT_panel)


def register():
    bpy.types.Scene.gt2_track_name = bpy.props.StringProperty(name="Track name", default="My Track")
    bpy.types.WindowManager.gt2_course = bpy.props.EnumProperty(name="Course", items=course_items)
    for c in classes:
        bpy.utils.register_class(c)
    course_edit.register()
    car_edit.register()


def unregister():
    car_edit.unregister()
    course_edit.unregister()
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    del bpy.types.WindowManager.gt2_course
    del bpy.types.Scene.gt2_track_name
