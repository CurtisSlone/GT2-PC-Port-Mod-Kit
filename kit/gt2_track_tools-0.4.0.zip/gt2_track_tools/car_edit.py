# Edit a GT2 car's model in Blender and put it back into the game (docs/crates/gt2-car.md "Editing in Blender").
#
# * "Export for editing": `gt2-tools car export CAR` (the folder the import rebuilds from) and `car export CAR
#   --edit` (CAR.edit.glb: the day model; with "Night model too" also CAR.night.edit.glb) into gt2-car/CAR next to
#   the .blend. Blender's own glTF importer reads the .glb: lod0, lod1, lod2, shadow and the wheel empties
#   wheel_0..3, the face ids as _GT2_* point attributes, materials `pal:NN` / `untex` / `shadow` (names only: no
#   pixels). Everything lands in a collection "GT2 car CAR (day)" that remembers the car and the file.
# * "Build edited car": Blender's glTF exporter writes the collection (custom attributes on, +Y up, UVs kept: the
#   car's UVs are its texture coordinates), the add-on puts the export's car/variant note (asset.extras.gt2_edit,
#   which Blender's exporter drops) back into the .glb, then `gt2-tools car import FOLDER --glb ... --out build`
#   rebuilds the model files and the mod Car_CAR gets them in carobj/.
# * "Preview": `gt2-tools car preview` (side, top, front, back) of the built car (or the original), shown in the
#   panel. The picture is made on this machine and is not saved in the .blend.

import json
import os
import shutil
import struct

import bpy
import bpy.utils.previews

from .course_edit import read_glb

CAR_PROP = "gt2_edit_car"
VARIANT_PROP = "gt2_edit_variant"
EXTRAS_PROP = "gt2_edit_extras"
PARTS = ("lod0", "lod1", "lod2", "shadow", "wheel_0", "wheel_1", "wheel_2", "wheel_3")


def _pkg():
    from . import (check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir)
    return check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, work_dir


def write_glb(path, gl, binc):
    js = json.dumps(gl, separators=(",", ":")).encode("utf-8")
    js += b" " * (-len(js) % 4)
    binc = bytes(binc) + b"\0" * (-len(binc) % 4)
    total = 12 + 8 + len(js) + (8 + len(binc) if binc else 0)
    with open(path, "wb") as f:
        f.write(b"glTF" + struct.pack("<II", 2, total))
        f.write(struct.pack("<I", len(js)) + b"JSON" + js)
        if binc:
            f.write(struct.pack("<I", len(binc)) + b"BIN\0" + binc)


def base_name(name):
    """lod0.001 -> lod0 (Blender's suffix for a second object of the same name)."""
    head, dot, tail = name.rpartition(".")
    return head if dot and tail.isdigit() else name


def import_car(glb, car, variant):
    """Blender's glTF importer on a car .edit.glb, into its own collection; returns the collection."""
    gl, _ = read_glb(glb)
    extras = gl.get("asset", {}).get("extras", {}).get("gt2_edit", {"car": car, "variant": variant})
    objs, mats = set(bpy.data.objects), set(bpy.data.materials)
    bpy.ops.import_scene.gltf(filepath=glb)
    new = [o for o in bpy.data.objects if o not in objs]
    col = bpy.data.collections.new(f"GT2 car {car} ({variant})")
    bpy.context.scene.collection.children.link(col)
    col[CAR_PROP] = car
    col[VARIANT_PROP] = variant
    col[EXTRAS_PROP] = json.dumps(extras)
    for o in new:
        for c in list(o.users_collection):
            c.objects.unlink(o)
        col.objects.link(o)
        o["gt2_car_part"] = base_name(o.name)
        # Materials are names the import reads (pal:NN): a second car's pal:02.001 goes back to pal:02.
        if o.type == 'MESH':
            for i, m in enumerate(o.data.materials):
                if m is not None and m not in mats:
                    keep = bpy.data.materials.get(base_name(m.name))
                    if keep is not None and keep is not m:
                        o.data.materials[i] = keep
    for m in [m for m in bpy.data.materials if m not in mats and m.users == 0]:
        bpy.data.materials.remove(m)
    if variant != "day":
        col.hide_viewport = True
    return col


def car_collections():
    return [c for c in bpy.data.collections if CAR_PROP in c]


def active_car(context):
    cols = car_collections()
    for c in cols:
        if context.collection is c or any(o in c.all_objects.values() for o in context.selected_objects):
            return c
    return cols[0] if cols else None


def export_car(col, path):
    """The collection's car parts through Blender's glTF exporter, then the car/variant note put back."""
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    obs = [o for o in col.all_objects if base_name(o.name) in PARTS or o.get("gt2_car_part") in PARTS]
    hidden_col = col.hide_viewport
    col.hide_viewport = False
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    hidden = []
    for o in obs:
        if o.hide_get():
            hidden.append(o)
            o.hide_set(False)
        o.select_set(True)
    try:
        bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_yup=True,
                                  export_apply=False, export_attributes=True, export_normals=False,
                                  export_texcoords=True, export_tangents=False, export_materials='EXPORT',
                                  export_image_format='NONE', export_vertex_color='NONE',
                                  export_animations=False, export_skins=False, export_morph=False,
                                  export_cameras=False, export_lights=False, export_extras=False)
    finally:
        for o in hidden:
            o.hide_set(True)
        col.hide_viewport = hidden_col
    gl, binc = read_glb(path)
    asset = gl.setdefault("asset", {})
    asset.setdefault("extras", {})["gt2_edit"] = json.loads(col[EXTRAS_PROP])
    # Node names as the import reads them (lod0, not lod0.001).
    for nd in gl.get("nodes", []):
        if "name" in nd:
            nd["name"] = base_name(nd["name"])
    for mt in gl.get("materials", []):
        if "name" in mt:
            mt["name"] = base_name(mt["name"])
    write_glb(path, gl, binc)
    return path


def car_work(car):
    from . import work_dir
    w = work_dir(os.path.join("gt2-car", car), need_saved=True)
    return w


# ---------------------------------------------------------------------------------------------------------------
# Car list (search field) and preview


_cars = []


def car_names():
    check_port, data_path, port_dir, gt2_tools, *_ = _pkg()
    if not _cars and not check_port():
        code, log = gt2_tools("car", "list", "--data", data_path(port_dir()), timeout=60)
        if code == 0:
            for l in log.splitlines():
                parts = l.split()
                if len(parts) >= 2 and all(p in ("cdo", "cdp", "cno", "cnp") for p in parts[1:]):
                    _cars.append(parts[0])
    return _cars


def car_search(self, context, edit_text):
    t = edit_text.lower().strip()
    return [c for c in car_names() if t in c][:400]


_preview = {"coll": None, "path": None, "icon": 0}


def preview_icon(path):
    """The preview picture as a panel icon (bpy.utils.previews: kept in memory, never in the .blend)."""
    if _preview["path"] == path and _preview["coll"] is not None:
        return _preview["icon"]
    if _preview["coll"] is not None:
        bpy.utils.previews.remove(_preview["coll"])
    pc = bpy.utils.previews.new()
    icon = pc.load("car", path, 'IMAGE').icon_id if os.path.isfile(path) else 0
    _preview.update(coll=pc, path=path, icon=icon)
    return icon


# ---------------------------------------------------------------------------------------------------------------
# Operators


class GT2TRACK_OT_car_export(bpy.types.Operator):
    """Export a car from your own data for editing (mesh only: lod0-2, shadow, wheel centers; materials are names)"""
    bl_idname = "gt2track.car_export"
    bl_label = "Export car for editing"

    car: bpy.props.StringProperty(name="Car")
    night: bpy.props.BoolProperty(name="Night model too", default=False)

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, *_ = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        car = self.car.strip()
        if not car:
            self.report({'ERROR'}, "Type a car code first (for example t2mgn)")
            return {'CANCELLED'}
        work = car_work(car)
        if work is None:
            self.report({'ERROR'}, "Save the file first (Ctrl+S): the car files are written next to it")
            return {'CANCELLED'}
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        data = data_path(port_dir())
        code, log = gt2_tools("car", "export", car, "--data", data, "--out", os.path.join(work, "folder"),
                              "--no-gltf")
        if code != 0:
            self.report({'ERROR'}, f"gt2-tools could not export {car}: {last_problem(log)}")
            return {'CANCELLED'}
        code, log = gt2_tools("car", "export", car, "--edit", "--data", data, "--out", work)
        glb = os.path.join(work, f"{car}.edit.glb")
        if code != 0 or not os.path.isfile(glb):
            self.report({'ERROR'}, f"gt2-tools could not export {car}: {last_problem(log)}")
            return {'CANCELLED'}
        import_car(glb, car, "day")
        if self.night and os.path.isfile(os.path.join(work, f"{car}.night.edit.glb")):
            import_car(os.path.join(work, f"{car}.night.edit.glb"), car, "night")
        self.report({'INFO'}, f"{car}: lod0 is the near model; keep the object names (lod0, wheel_0...)")
        return {'FINISHED'}


class GT2TRACK_OT_car_build(bpy.types.Operator):
    """Put the edited car back: gt2-tools car import --glb, installed as the mod Car_<car>"""
    bl_idname = "gt2track.car_build"
    bl_label = "Build edited car"

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, mods_path, install_mod, _ = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        col = active_car(context)
        if col is None:
            self.report({'ERROR'}, "No GT2 car to build: use Export car for editing first")
            return {'CANCELLED'}
        car = col[CAR_PROP]
        work = car_work(car)
        if work is None:
            self.report({'ERROR'}, "Save the file first (Ctrl+S)")
            return {'CANCELLED'}
        folder = os.path.join(work, "folder")
        if not os.path.isdir(folder):
            self.report({'ERROR'}, f"{folder} is missing: use Export car for editing again")
            return {'CANCELLED'}
        args = ["car", "import", folder, "--out", os.path.join(work, "build")]
        variants = []
        for c in car_collections():
            if c[CAR_PROP] == car:
                v = c[VARIANT_PROP]
                path = export_car(c, os.path.join(work, f"{car}.{v}.edited.glb"))
                args += ["--glb", path]
                variants.append(v)
        code, log = gt2_tools(*args)
        with open(os.path.join(work, "build-log.txt"), "w", encoding="utf-8") as f:
            f.write(log)
        if code != 0:
            self.report({'ERROR'}, f"gt2-tools car import said no: {last_problem(log)}  (all of it: "
                                   f"gt2-car/{car}/build-log.txt)")
            return {'CANCELLED'}
        # The mod: the edited models only (the textures are the game's own).
        modname = f"Car_{car}"
        stage = os.path.join(work, "mod", modname)
        shutil.rmtree(os.path.join(work, "mod"), ignore_errors=True)
        os.makedirs(os.path.join(stage, "carobj"))
        for v in variants:
            ext = "cdo" if v == "day" else "cno"
            src = os.path.join(work, "build", f"{car}.{ext}")
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(stage, "carobj", f"{car}.{ext}"))
        install_mod(stage, mods_path(port_dir()), modname)
        context.window_manager.gt2_car_preview_src = "build"
        changed = [l for l in log.splitlines() if "->" in l]
        self.report({'INFO'}, f"Built {car} ({', '.join(variants)}): {len(changed)} parts changed; mod {modname} "
                              "is on in mods/load-order.txt")
        return {'FINISHED'}


class GT2TRACK_OT_car_preview(bpy.types.Operator):
    """Draw the car from the side, top, front and back (gt2-tools car preview): the built car, else the original"""
    bl_idname = "gt2track.car_preview"
    bl_label = "Preview"

    car: bpy.props.StringProperty(name="Car")
    night: bpy.props.BoolProperty(name="Night")

    def execute(self, context):
        check_port, data_path, port_dir, gt2_tools, last_problem, *_ = _pkg()
        problems = check_port()
        if problems:
            self.report({'ERROR'}, problems[0])
            return {'CANCELLED'}
        car = self.car.strip()
        work = car_work(car) if car else None
        if work is None:
            self.report({'ERROR'}, "Type a car code and save the file first")
            return {'CANCELLED'}
        build = os.path.join(work, "build")
        src = build if os.path.isfile(os.path.join(build, f"{car}.cdo")) else data_path(port_dir())
        out = os.path.join(work, f"{car}-preview{'-night' if self.night else ''}.png")
        args = ["car", "preview", car, "--data", src, "--out", out] + (["--night"] if self.night else [])
        code, log = gt2_tools(*args)
        if code != 0 or not os.path.isfile(out):
            self.report({'ERROR'}, f"gt2-tools car preview: {last_problem(log)}")
            return {'CANCELLED'}
        context.window_manager.gt2_car_preview = out
        _preview["path"] = None
        what = "built" if src == build else "original"
        self.report({'INFO'}, f"Preview of the {what} {car}: {out}")
        return {'FINISHED'}


class GT2TRACK_PT_car(bpy.types.Panel):
    bl_label = "GT2 Car"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT2"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        lay = self.layout
        wm = context.window_manager
        lay.prop(wm, "gt2_car", text="Car")
        row = lay.row(align=True)
        op = row.operator("gt2track.car_export", icon='IMPORT')
        op.car = wm.gt2_car
        op.night = wm.gt2_car_night
        lay.prop(wm, "gt2_car_night")
        col = active_car(context)
        lay.operator("gt2track.car_build", icon='AUTO',
                     text=f"Build edited car ({col[CAR_PROP]})" if col else "Build edited car")
        row = lay.row(align=True)
        op = row.operator("gt2track.car_preview", icon='IMAGE_DATA')
        op.car = col[CAR_PROP] if col else wm.gt2_car
        op.night = False
        if wm.gt2_car_preview and os.path.isfile(wm.gt2_car_preview):
            icon = preview_icon(wm.gt2_car_preview)
            if icon:
                lay.template_icon(icon_value=icon, scale=12.0)
            lay.label(text=os.path.basename(wm.gt2_car_preview))
        box = lay.box()
        box.label(text="Move vertices, delete or add faces;")
        box.label(text="keep the names lod0, lod1, lod2, wheel_0.")
        box.label(text="New faces: a pal:NN or untex material.")
        box.label(text="Mesh only: the paint is the game's.")


classes = (GT2TRACK_OT_car_export, GT2TRACK_OT_car_build, GT2TRACK_OT_car_preview, GT2TRACK_PT_car)


def register():
    wm = bpy.types.WindowManager
    wm.gt2_car = bpy.props.StringProperty(name="Car", default="", search=car_search,
                                          description="The car's code (file name), for example t2mgn")
    wm.gt2_car_night = bpy.props.BoolProperty(name="Night model too", default=False,
                                              description="Also open the night model (races at night use it)")
    wm.gt2_car_preview = bpy.props.StringProperty(name="Preview picture", default="")
    wm.gt2_car_preview_src = bpy.props.StringProperty(default="")
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    if _preview["coll"] is not None:
        bpy.utils.previews.remove(_preview["coll"])
        _preview.update(coll=None, path=None, icon=0)
    wm = bpy.types.WindowManager
    for p in ("gt2_car", "gt2_car_night", "gt2_car_preview", "gt2_car_preview_src"):
        delattr(wm, p)
